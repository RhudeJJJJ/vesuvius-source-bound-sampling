# Fixing source-bound sampling identities in ink_9um

**Technical implementation and internal validation complete. Publication and
Progress Prize submission pending.** This standalone repository package is
our proposed submission artifact. It does not claim a villa pull request,
completed human review, external peer review, acceptance or an award.

## Problem and correction

At villa commit `a4979b99004934955784ea19b30da66cfe5f9ead`, the aligned21
configs assign `pherc0139-w028` and native `w044` to separate physical sampling
keys. The [publisher's source table](https://huggingface.co/buckets/scrollprize/datasets/tree/ink_9um)
assigns both to `PHerc0139/segments/20260115000000-w044_2026011522`, in
different CT scans.

The patch changes the aligned label's physical key to `0139:w044` in both
configs. All 29 representations, distinct representation keys, source frames
and batch quotas remain. The production sampler is unchanged. A separate
source manifest and checker prevent both source splits and false merges;
folder suffixes are not an identity rule.

## Measured result

Normal production imports discovered patches from all 29 complete original
level-0 label stores. The replay retained four genuine patches per
representation: the same bounded 116-patch inventory before and after.
Separate checking confirmed every selected crop's training eligibility.

| Measurement | Original | Corrected |
|---|---:|---:|
| Authored PHerc. 0139 budget groups; publisher reference is 9 | 10 | 9 |
| Draws for the shared public w044 source over 90 batches | 522 | 290 |
| Emitted index batches / indices | 90 / 5,760 | 90 / 5,760 |
| Source-bound batch-boundary balance audit | FAIL at all 90 boundaries | PASS |
| Actual DataLoader batches / returned samples | 1 / 64 | 1 / 64 |

The affected source's original overweight is `522/290 = 9/5 = 1.8`.
Scroll totals remain `0139=2610`, `1667=1980`, `Paris4=990`, `0814=180`.
The nine corrected PHerc. 0139 source groups each receive 290 draws.
The 90-batch traces measure sampler emission; only one actual 64-sample
DataLoader batch per variant was consumed.

Both returned batches include all 29 representations. Their union contains
67 genuine crops. A separate checker reconstructed all 67 tensor triples
from original masks and source-backed CT tiles; 61 shared same-frame crop
indices have identical tensor hashes. It audited 113 prepared CT tiles and
171 source objects; the payloads required 109 of those tiles. Unknown
unprepared canvas tiles were blocked before reads.

The original-label audit covers 370,331 publisher objects and 13,581 unique
blob proof records: 65 metadata blobs and 13,516 independently decoded chunk
blobs, totaling 4,750,835,712 decoded bytes. Exactly 351,643 objects were
omitted locally only after complete fill-value proofs; 18,688 non-fill or
metadata objects remain. These are label/CT/runtime observations, not model
training or score measurements.

Read the [internal verification summary](verification/internal_verification_summary.json),
[trace audit](verification/real_after_trace_audit.json),
[CT audit](verification/final_ct_source_and_tile_audit.json),
[tensor-chain audit](verification/real_chain_and_tensor_audit.json), and
[execution receipt](evidence/implementation-execution-receipt.json).
The separate patch replay also records 24 passing focused tests.

## Boundaries and provenance

This work is AI assisted, including implementation and the separate technical
checkers. Validation is internal technical checking. Human/external review,
external usefulness, model gain and a causal Aletheion/Semantic Metrology
benefit remain unestablished. Publisher segment grouping does not prove
cross-scan pixel identity or registration accuracy. Count balance is a
necessary queue consequence; shuffled batches do not expose internal pop
order. Total discovery counts and first-four order were not independently
replayed; all 116 selected crop eligibility predicates were checked.

The completed label materializer loaded the saved `f8ee8d5f…` source snapshot.
Delivered `runtime/data_access.py` is a later `5eefee9a…` version with one
read-only inventory scope narrowed; full execution of that later file is not
claimed. [execution-source-map.json](execution-source-map.json) binds executed,
checked and delivered source digests separately.

Public reports remove private absolute paths and URL queries. Raw and public
copy hashes are recorded in [package-manifest.json](package-manifest.json).
Original reference hashes remain archival facts; sanitized copies are not
replacement operational receipts for byte-identity gates. Fresh replay creates
its own local receipts. The compressed catalog and sanitized proof records
are included; large caches, label stores and CT arrays are recreated.

## Reproduce

Use Git and Python **3.14** from this package root. The recorded environment
is Python 3.14.8 on Windows; other platforms were not tested by this run.
The POSIX commands below use equivalent relative paths. On Windows substitute
`runtime/venv/Scripts/python.exe` and set
`$env:PYTHONPATH = (Resolve-Path vendor/villa/vesuvius/src).Path`.

```bash
mkdir -p vendor
git clone --config core.autocrlf=false https://github.com/ScrollPrize/villa.git vendor/villa

git -C vendor/villa checkout --detach a4979b99004934955784ea19b30da66cfe5f9ead
git -C vendor/villa apply --check ../../upstream.patch
git -C vendor/villa apply ../../upstream.patch
python3.14 -m venv runtime/venv
runtime/venv/bin/python -m pip install -r runtime/requirements.lock.txt
export PYTHONPATH="$PWD/vendor/villa/vesuvius/src"
runtime/venv/bin/python -P vendor/villa/vesuvius/src/vesuvius/ink_detection/source_identity.py
runtime/venv/bin/python -m pytest vendor/villa/vesuvius/tests/ink_detection/test_source_identity.py vendor/villa/vesuvius/tests/ink_detection/test_shipped_configs.py -q
```

Public data are mutable. These commands obtain a fresh full listing and
recreate local real-data artifacts. The 160 MB listing / 200 MB unique object
caps bound returned payloads, not time or transport overhead. Inspect reported
sizes before changing caps. `--xet` uses official anonymous Hugging Face
transport; omit it for direct public-object access.

```bash
runtime/venv/bin/python verification/independent_fixed_prior.py acquire
runtime/venv/bin/python verification/independent_fixed_prior.py oracle
runtime/venv/bin/python runtime/data_access.py probe --all-representations --cap 160000000
runtime/venv/bin/python verification/independent_fixed_prior.py audit-label-metadata verification/original_label_metadata_audit.json --fetch-critical
runtime/venv/bin/python runtime/data_access.py materialize --xet --cap 200000000 --workers 4 --output runtime/data --summary runtime/labels-summary.json --receipts evidence/label-object-receipts.jsonl
runtime/venv/bin/python verification/verify_materialization.py --summary runtime/labels-summary.json --report runtime/data-access-report.json --output verification/original_all29_mask_materialization_audit.json
runtime/venv/bin/python runtime/prepare_real_ct.py metadata --workers 4
cp runtime/ct-manifest.json evidence/ct-manifest-before-discovery.json
runtime/venv/bin/python runtime/real_pipeline.py discover --patches-per-representation 4 --ct-manifest evidence/ct-manifest-before-discovery.json
runtime/venv/bin/python verification/verify_patch_eligibility.py runtime/real-discovery.json verification/real_patch_eligibility_audit.json
runtime/venv/bin/python runtime/real_pipeline.py sample --batches 90 --ct-manifest evidence/ct-manifest-before-discovery.json
runtime/venv/bin/python verification/independent_fixed_prior.py audit-trace runtime/real-results/before-trace.json verification/real_before_trace_audit.json
runtime/venv/bin/python verification/independent_fixed_prior.py audit-trace runtime/real-results/after-trace.json verification/real_after_trace_audit.json
runtime/venv/bin/python runtime/real_pipeline.py plan-load --load-batches 1
runtime/venv/bin/python runtime/prepare_real_ct.py prepare --load-plan runtime/real-load-plan.json --workers 4
cp runtime/ct-manifest.json evidence/ct-manifest-at-load.json
runtime/venv/bin/python runtime/real_pipeline.py load --ct-manifest evidence/ct-manifest-at-load.json
runtime/venv/bin/python verification/verify_ct_artifacts.py --manifest evidence/ct-manifest-at-load.json --verify-tiles --output verification/final_ct_source_and_tile_audit.json
runtime/venv/bin/python verification/verify_real_chain.py
```

Expected: before balance FAIL, corrected balance PASS, 522 versus 290 w044
draws, two actual 64-sample batches total, unchanged shared-crop tensor hashes,
and separate mask/CT/tensor checks PASS. Preserve any upstream byte or schema
drift rather than treating a new hash as proof of unchanged data.

## Attribution and submission route

Code follows the retained upstream [MIT license](LICENSE). Data rights are
separate: see [DATA-ATTRIBUTION.md](DATA-ATTRIBUTION.md), the
[Vesuvius Challenge data portal](https://scrollprize.org/data),
[original source table](https://huggingface.co/buckets/scrollprize/datasets/resolve/ink_9um/README.md),
and [released model input description](https://huggingface.co/scrollprize/ink_9um).
The proposed Progress Prize route is this public repository and its evidence
package. Publication URL and submission receipt are recorded only after the
corresponding actions occur. [validation-status.json](validation-status.json)
currently keeps publication and submission pending.
