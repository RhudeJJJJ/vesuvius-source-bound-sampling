"""Check individual real training crops without replaying full discovery."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def read_json(path):
    return json.loads(Path(path).read_text("utf-8"))


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("discovery", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    raw = args.discovery.read_bytes()
    discovery = json.loads(raw)
    original_masks = read_json(ROOT / "verification/original_all29_mask_materialization_audit.json")
    if original_masks["status"] != "PASS" or original_masks["selected_representation_count"] != 29:
        raise ValueError("full independently verified original mask materialization is required")
    import numpy as np
    import zarr
    config = discovery["config"]
    if config["mode"] != "flat":
        raise ValueError("this independent eligibility check is limited to released flat mode")
    requested_shape = config["patch_size"]
    patch_depth, patch_height, patch_width = requested_shape
    # The production contract calls this fraction overlap but uses it as stride.
    strides = [int(patch_height * config["patch_overlap"]), int(patch_width * config["patch_overlap"])]
    threshold = config["patch_min_labeled_coverage"]
    if min(strides) <= 0:
        raise ValueError("positive released stride required")
    arrays, results, failures, counts = {}, [], [], Counter()

    def get_array(path):
        path = Path(path)
        key = str(path.resolve())
        if key not in arrays:
            arrays[key] = zarr.open_group(key, mode="r")["0"]
        return arrays[key]

    for patch in discovery["patches"]:
        index, dataset_idx, label = patch["index"], patch["dataset_idx"], patch["segment_relpath"]
        dataset = config["datasets"][dataset_idx]
        label_dir = Path(dataset["segments_path"]) / label
        expected_ink = label_dir / f"{label}_inklabels.zarr"
        expected_supervision = label_dir / f"{label}_supervision_mask.zarr"
        if Path(patch["inklabels"]).resolve() != expected_ink.resolve() or Path(patch["supervision_mask"]).resolve() != expected_supervision.resolve():
            failures.append({"kind": "individual_patch_original_asset_binding", "index": index})
        if patch["is_validation"] or patch["is_unlabeled"]:
            failures.append({"kind": "individual_patch_training_role", "index": index})
        ink = get_array(patch["inklabels"])
        supervision = get_array(patch["supervision_mask"])
        validation = None if patch["validation_mask"] is None else get_array(patch["validation_mask"])
        image_schema = read_json(Path(patch["image_volume"]) / "0/.zarray")
        image_depth = image_schema["shape"][0]
        center = image_depth // 2
        expected_z0 = center - patch_depth // 2
        z0, y0, x0, z1, y1, x1 = patch["bbox"]
        if [z1-z0, y1-y0, x1-x0] != requested_shape or z0 != expected_z0 or z1 != expected_z0 + patch_depth:
            failures.append({"kind": "individual_patch_bbox_shape_or_center", "index": index})
        if y0 < 0 or x0 < 0 or y0 % strides[0] or x0 % strides[1]:
            failures.append({"kind": "individual_patch_stride_origin", "index": index})
        if list(ink.shape) != list(supervision.shape) or list(ink.shape) != image_schema["shape"] or validation is not None and list(validation.shape) != list(ink.shape):
            failures.append({"kind": "individual_patch_asset_shapes", "index": index})
        sup_cell = np.asarray(supervision[center, y0:min(y0+strides[0], supervision.shape[1]), x0:min(x0+strides[1], supervision.shape[2])])
        supported = sup_cell > 0
        if validation is not None:
            val_cell = np.asarray(validation[center, y0:min(y0+strides[0], validation.shape[1]), x0:min(x0+strides[1], validation.shape[2])])
            supported = supported | (val_cell > 0)
        if not np.any(supported):
            failures.append({"kind": "individual_patch_stride_support_witness", "index": index})
        sup_crop = np.asarray(supervision[center, y0:min(y1, supervision.shape[1]), x0:min(x1, supervision.shape[2])])
        ink_crop = np.asarray(ink[center, y0:min(y1, ink.shape[1]), x0:min(x1, ink.shape[2])])
        val_crop = None if validation is None else np.asarray(validation[center, y0:min(y1, validation.shape[1]), x0:min(x1, validation.shape[2])])
        eligible = bool(np.any(sup_crop))
        if val_crop is not None and np.any(val_crop):
            eligible = eligible and bool(np.any(sup_crop & ~val_crop))
        if not eligible:
            failures.append({"kind": "individual_patch_exact_training_mask_predicate", "index": index})
        coordinates = np.argwhere(ink_crop != 0)
        rectangle_area = 0 if len(coordinates) == 0 else int(np.prod(coordinates.max(axis=0) - coordinates.min(axis=0) + 1))
        coverage = rectangle_area / ink_crop.size if ink_crop.size else 0.0
        if coverage < threshold:
            failures.append({"kind": "individual_patch_ink_bounding_rectangle_coverage", "index": index, "coverage": coverage})
        effective = sup_crop if val_crop is None else np.where(val_crop > 0, 0, sup_crop)
        results.append({"index": index, "representation_key": patch["representation_key"], "bbox": patch["bbox"], "center_plane": center, "candidate_support_witness": bool(np.any(supported)), "exact_original_training_mask_predicate": eligible, "ink_nonzero_pixels": len(coordinates), "ink_bounding_rectangle_coverage": coverage, "supervision_after_validation_nonzero": int(np.count_nonzero(effective)), "clipped_crop_shape": list(ink_crop.shape), "outside_canvas_padding_pixels": patch_height*patch_width-ink_crop.size})
        counts[patch["representation_key"]] += 1
    if args.discovery.read_bytes() != raw:
        raise ValueError("discovery bytes changed during bounded eligibility checks")
    result = {"status": "PASS" if not failures else "FAIL", "scope": "Individual source-bound training-patch eligibility in released flat finder contract", "discovery_sha256": hashlib.sha256(raw).hexdigest(), "full_original_mask_audit_sha256": hashlib.sha256((ROOT / "verification/original_all29_mask_materialization_audit.json").read_bytes()).hexdigest(), "strides_yx": strides, "coverage_definition": "nonzero ink bounding-rectangle area / actual clipped label crop area", "training_validation_definition": "exact original uint8 bitwise finder predicate; actual loader later zeros training supervision wherever validation>0", "patches_checked": len(results), "representations_checked": len(counts), "patches_by_representation": dict(sorted(counts.items())), "patch_results": results, "failures": failures, "limits": ["Does not establish total discovery counts or first-four ordering; no full discovery rerun was made.", "Zero positive ink labels are allowed by the released threshold 0.0.", "Train and validation can share a bbox; overlap is handled by loader masking, not excluded by bbox identity.", "Individual masks/padding are checked; no cross-frame pixel identity, label truth, model gain or external peer review is inferred."]}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", "utf-8")
    print(json.dumps({"status": result["status"], "patches_checked": len(results), "representations_checked": len(counts), "failure_count": len(failures)}, indent=2))


if __name__ == "__main__":
    main()
