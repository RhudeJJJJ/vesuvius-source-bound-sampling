"""Independent source-bound checker; no imports from villa sampler code.

The source oracle is derived before reading the proposed correction. Runtime
checks consume global patch indices and a loader-emitted patch inventory.
Internal review only: this is not an external peer review or an ML evaluation.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "verification"
ORIGINALS = OUT / "originals"
BASE = "a4979b99004934955784ea19b30da66cfe5f9ead"
FAMILIES = {
    "aligned-scrollprizeorg-21slices": "public_2p4_level2_zmean4",
    "native9-scrollprizeorg-21slices": "native_9p362_level0",
}
SCROLLS = {"PHerc0139": "0139", "PHerc1667": "1667", "PHercParis4": "Paris4", "PHerc0814": "0814"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def save_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def acquire() -> None:
    ORIGINALS.mkdir(parents=True, exist_ok=True)
    manifest = {"observed_at": datetime.now(timezone.utc).isoformat(), "base_commit": BASE, "sources": []}
    public = {
        "ink_9um_README.md": "https://huggingface.co/buckets/scrollprize/datasets/resolve/ink_9um/README.md",
        "ink_9um_model_README.md": "https://huggingface.co/scrollprize/ink_9um/resolve/main/README.md",
    }
    for filename, url in public.items():
        with urlopen(Request(url, headers={"User-Agent": "independent-fixed-prior-audit/1"}), timeout=60) as response:
            data = response.read()
            final_url = response.url
        (ORIGINALS / filename).write_bytes(data)
        manifest["sources"].append({"file": filename, "url": url, "redirect_host": urlsplit(final_url).netloc, "bytes": len(data), "sha256": digest(data)})
    paths = ["AGENTS.md", "CONTRIBUTING.md", "vesuvius/src/vesuvius/ink_detection/training/samplers.py", "vesuvius/src/vesuvius/ink_detection/types.py", "vesuvius/src/vesuvius/ink_detection/configs/aligned21_hybrid_3d2d.json", "vesuvius/src/vesuvius/ink_detection/configs/aligned21_fixed_scroll_prior.json"]
    for path in paths:
        data = subprocess.check_output(["git", "-C", str(ROOT / "vendor/villa"), "show", f"{BASE}:{path}"])
        filename = Path(path).name
        (ORIGINALS / filename).write_bytes(data)
        manifest["sources"].append({"file": filename, "git_path": path, "commit": BASE, "bytes": len(data), "sha256": digest(data)})
    save_json(OUT / "source_manifest.json", manifest)
    print(json.dumps(manifest, indent=2))


def family_for_path(path: str) -> str:
    matches = [family for folder, family in FAMILIES.items() if folder in path.replace("\\", "/").split("/")]
    if len(matches) != 1:
        raise ValueError(f"source-family path is ambiguous/unbound: {path!r}")
    return matches[0]


def source_address(url: str) -> tuple[str, str, str, str]:
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != "vesuvius-challenge-open-data.s3.amazonaws.com":
        raise ValueError(f"source volume is outside the original public host: {url}")
    if parsed.fragment and parsed.path != "/index.html":
        raise ValueError("publisher fragments are only accepted on the original index.html reference")
    path = unquote(parsed.fragment if parsed.fragment else parsed.path).strip("/")
    parts = path.split("/")
    if "segments" not in parts or "surface-volumes" not in parts:
        raise ValueError(f"not an explicit source-volume link: {url}")
    pos = parts.index("segments")
    scroll, segment_id = parts[pos - 1], parts[pos + 1]
    frame = parts[parts.index("surface-volumes") + 1]
    return SCROLLS[scroll], scroll, segment_id, frame


def build_oracle() -> None:
    raw = (ORIGINALS / "ink_9um_README.md").read_text(encoding="utf-8")
    rows = []
    family = None
    for line in raw.splitlines():
        if line.startswith("Aligned public 2.399"):
            family = "public_2p4_level2_zmean4"
        elif line.startswith("Native 9.362"):
            family = "native_9p362_level0"
        match = re.match(r"\|?\s*([^|]+)\s*\|\s*([^|]+)\s*\|\s*\[([^]]+)\]\(([^)]+)\)", line)
        if family is None or not match:
            continue
        label, scroll_label, caption, url = (item.strip() for item in match.groups())
        scroll, source_scroll, segment_id, frame = source_address(url)
        rows.append({"family": family, "label_segment": label, "scroll": scroll, "source_scroll": source_scroll, "public_segment_id": segment_id, "source_frame": frame, "source_volume_url": url, "source_caption": caption, "physical_reference": f"{source_scroll}/segments/{segment_id}", "representation_reference": f"{family}:{label}", "label_frame": {"depth": 21, "annotated_z": 10} if family == "public_2p4_level2_zmean4" else {"depth": 28, "annotated_z": 14}})
    if len(rows) != 29:
        raise ValueError(f"original source table parse yielded {len(rows)} rows, expected released table size 29")
    keys = [(row["family"], row["label_segment"]) for row in rows]
    if len(keys) != len(set(keys)):
        raise ValueError("duplicate source table representation")
    by_physical = defaultdict(list)
    by_scroll = defaultdict(set)
    for row in rows:
        by_physical[row["physical_reference"]].append(row["representation_reference"])
        by_scroll[row["scroll"]].add(row["physical_reference"])
    oracle = {"status": "SOURCE_BOUND_BEFORE_CORRECTION_CODE", "source_readme_sha256": digest((ORIGINALS / "ink_9um_README.md").read_bytes()), "identity_rule": "Physical budget equivalence uses exact source scroll plus public segment ID extracted from explicit README links; source frame and label representation remain distinct.", "identity_limit": "Same public segment ID binds the budget group; it does not prove identical physical pixel supports, scanframe coordinates, arrays, values, or transferred-label correctness.", "rows": rows, "physical_groups_by_scroll": {key: sorted(values) for key, values in by_scroll.items()}, "representations_by_physical": dict(sorted(by_physical.items())), "source_frames": sorted({row["source_frame"] for row in rows}), "budget_contract": {"batch_size": 64, "scroll_quotas": {"0139": 29, "1667": 22, "Paris4": 11, "0814": 2}, "physical_mass": "quota(scroll) / number of active source-bound physical groups in scroll", "representation_mass": "physical mass / number of active representations in physical group", "active": "A representation/group is active exactly when the discovered training-patch inventory includes it. Missing configured entries remain separately reported.", "balance": "At batch boundaries, cumulative counts over each physical queue or representation queue differ by at most one, starting at initial queue state.", "queue_limit": "Final batch shuffling obscures within-batch pop order; batch-boundary count balance does not alone prove strict no-repeat-before-exhaustion ordering."}}
    save_json(OUT / "source_oracle.json", oracle)
    print(json.dumps({"rows": len(rows), "physical_groups_by_scroll": {key: len(values) for key, values in by_scroll.items()}, "paired_representations": {key: values for key, values in by_physical.items() if len(values) > 1}}, indent=2))


def bind_config(config: dict, oracle: dict) -> list[dict]:
    table = {(row["family"], row["label_segment"]): row for row in oracle["rows"]}
    result = []
    for dataset_idx, dataset in enumerate(config["datasets"]):
        family = family_for_path(dataset["segments_path"])
        for label in dataset["segments"]:
            row = table.get((family, label))
            if row is None:
                raise ValueError(f"no original source for {(family, label)!r}")
            result.append({**row, "dataset_idx": dataset_idx, "segment_relpath": label, "configured_scroll": dataset.get("sampling_scroll"), "configured_physical": dataset.get("sampling_physical_segment_keys", {}).get(label), "configured_representation": dataset.get("sampling_representation_keys", {}).get(label), "configured_volume_path": dataset.get("surface_volume_paths", {}).get(label), "configured_segments_path": dataset["segments_path"]})
    return result


def inspect_config(config_path: Path, output: Path) -> None:
    oracle = read_json(OUT / "source_oracle.json")
    rows = bind_config(read_json(config_path), oracle)
    failures = []
    for row in rows:
        if row["configured_scroll"] != row["scroll"]:
            failures.append({"kind": "wrong_scroll", "row": row})
        if not row["configured_physical"] or not row["configured_representation"]:
            failures.append({"kind": "missing_mapping", "row": row})
    for i, left in enumerate(rows):
        for right in rows[i + 1:]:
            reference_same = left["physical_reference"] == right["physical_reference"]
            configured_same = left["configured_physical"] == right["configured_physical"]
            if reference_same != configured_same:
                failures.append({"kind": "split_physical" if reference_same else "merge_distinct_physical", "left": left["representation_reference"], "right": right["representation_reference"], "reference_left": left["physical_reference"], "reference_right": right["physical_reference"], "configured_left": left["configured_physical"], "configured_right": right["configured_physical"]})
            if left["configured_representation"] == right["configured_representation"]:
                failures.append({"kind": "merge_representations", "left": left["representation_reference"], "right": right["representation_reference"]})
    configured_references = {row["representation_reference"] for row in rows}
    missing_references = sorted(row["representation_reference"] for row in oracle["rows"] if row["representation_reference"] not in configured_references)
    save_json(output, {"status": "PASS" if not failures else "FAIL", "scope": "Configuration equivalence partition; no runtime or pixel-equivalence claim", "config_sha256": digest(config_path.read_bytes()), "source_oracle_sha256": digest((OUT / "source_oracle.json").read_bytes()), "representations": rows, "source_representations_not_configured": missing_references, "failures": failures})
    print(json.dumps({"status": "PASS" if not failures else "FAIL", "failure_count": len(failures), "failure_kinds": dict(Counter(row["kind"] for row in failures)), "source_representations_not_configured": missing_references}, indent=2))


def audit_trace(trace_path: Path, output: Path) -> None:
    """Count emitted indices using source-bound identities, never sampler audits.

    Trace schema: config; patches [{index,dataset_idx,segment_relpath,...}];
    batches [[index,...]]; trace_origin; trace_starts_at_sampler_initialization.
    Optional source_bindings uses representation_reference as its key.
    """
    trace = read_json(trace_path)
    oracle = read_json(OUT / "source_oracle.json")
    rows = bind_config(trace["config"], oracle)
    bound = {(row["dataset_idx"], row["segment_relpath"]): row for row in rows}
    inventory = {}
    failure_counts = Counter()
    failures = []

    def fail(kind, **detail):
        failure_counts[kind] += 1
        if len(failures) < 200:
            failures.append({"kind": kind, **detail})

    active_physical = defaultdict(set)
    active_repr = defaultdict(set)
    active_patches = defaultdict(set)
    inventory_phys = Counter()
    inventory_rep = Counter()
    source_bindings = trace.get("source_bindings", {})
    provenance_checks = []
    for patch in trace["patches"]:
        index = patch["index"]
        if isinstance(index, bool) or not isinstance(index, int) or index < 0:
            raise ValueError("inventory indices must be nonnegative integers")
        if index in inventory:
            raise ValueError(f"duplicate inventory patch index: {index}")
        row = bound[(patch["dataset_idx"], patch["segment_relpath"])]
        inventory[index] = {**patch, "reference": row}
        active_physical[row["scroll"]].add(row["physical_reference"])
        active_repr[row["physical_reference"]].add(row["representation_reference"])
        active_patches[row["representation_reference"]].add(index)
        inventory_phys[row["physical_reference"]] += 1
        inventory_rep[row["representation_reference"]] += 1
    if not inventory:
        raise ValueError("empty discovered-patch inventory")
    if set(inventory) != set(range(len(inventory))):
        fail("inventory_not_contiguous", expected_size=len(inventory))
    for representation in sorted(active_patches):
        row = next(row for row in rows if row["representation_reference"] == representation)
        binding = source_bindings.get(representation, {})
        original_url = binding.get("original_source_volume_url")
        if original_url:
            expected = source_address(row["source_volume_url"])
            actual_parsed = urlsplit(original_url)
            if actual_parsed.fragment or actual_parsed.query or actual_parsed.path == "/index.html":
                fail("actual_source_fetch_url_not_canonical", representation=representation)
            observed = source_address(original_url)
            if observed != expected:
                fail("wrong_source_frame_or_segment", representation=representation, expected=list(expected), observed=list(observed))
            provenance_checks.append({"representation": representation, "status": "DECLARED_FRAME_MATCH" if observed == expected else "FAIL", "source_binding": binding})
        else:
            provenance_checks.append({"representation": representation, "status": "ACTUAL_VOLUME_PROVENANCE_NOT_SUPPLIED"})
    quotas = oracle["budget_contract"]["scroll_quotas"]
    configured_quotas = trace["config"].get("fixed_scroll_prior", {}).get("target_batch_counts", {})
    if configured_quotas != quotas:
        fail("configured_quotas_disagree_with_original_contract", expected=quotas, observed=configured_quotas)
    if set(active_physical) != set(quotas):
        fail("active_scrolls_disagree_with_contract", expected=sorted(quotas), observed=sorted(active_physical))
    scroll_counts, physical_counts, repr_counts, patch_counts = Counter(), Counter(), Counter(), Counter()
    initial = trace.get("trace_starts_at_sampler_initialization") is True
    prefix_balance_checked = initial
    batches = trace["batches"]
    for batch_number, batch in enumerate(batches):
        if isinstance(batch, dict):
            batch = batch["indices"]
        if len(batch) != oracle["budget_contract"]["batch_size"]:
            fail("batch_size", batch=batch_number, observed=len(batch))
        batch_scroll_counts = Counter()
        for index in batch:
            if isinstance(index, bool) or not isinstance(index, int) or index not in inventory:
                fail("unknown_patch_index", batch=batch_number, index=index)
                continue
            patch = inventory[index]
            row = patch["reference"]
            if patch.get("is_validation") is True or patch.get("is_unlabeled") is True:
                fail("nontraining_patch_emitted", batch=batch_number, index=index)
            batch_scroll_counts[row["scroll"]] += 1
            scroll_counts[row["scroll"]] += 1
            physical_counts[row["physical_reference"]] += 1
            repr_counts[row["representation_reference"]] += 1
            patch_counts[index] += 1
        if dict(batch_scroll_counts) != quotas:
            fail("batch_scroll_quotas", batch=batch_number, observed=dict(batch_scroll_counts), expected=quotas)
        if initial:
            for scroll, physicals in active_physical.items():
                counts = [physical_counts[physical] for physical in physicals]
                if max(counts) - min(counts) > 1:
                    fail("physical_prefix_balance", batch=batch_number, scroll=scroll, counts={physical: physical_counts[physical] for physical in sorted(physicals)})
            for physical, representations in active_repr.items():
                counts = [repr_counts[representation] for representation in representations]
                if max(counts) - min(counts) > 1:
                    fail("representation_prefix_balance", batch=batch_number, physical=physical, counts={representation: repr_counts[representation] for representation in sorted(representations)})
            for representation, indices in active_patches.items():
                counts = [patch_counts[index] for index in indices]
                if max(counts) - min(counts) > 1:
                    fail("patch_prefix_balance", batch=batch_number, representation=representation, count_range=[min(counts), max(counts)])
    active_references = set(active_patches)
    configured_references = {row["representation_reference"] for row in rows}
    source_references = {row["representation_reference"] for row in oracle["rows"]}
    limitations = ["Internal technical verification, not external peer review.", "Source-table equivalence is a declared budget identity; pixel identity, registration accuracy and label correctness were not established.", "No training, validation-score improvement, model gain, external usefulness or causal Aletheion benefit is inferred.", "Final batch order is shuffled; prefix counts do not prove internal queue-pop order without an unshuffled production trace.", "Producer-supplied artifact hashes and source bindings require independent byte/receipt checking to establish actual local frame provenance.", "This audit counts the supplied emitted indices. DataLoader return/consumption and sampler-to-DataLoader emission remain separate endpoints, particularly with prefetching."]
    if not initial:
        limitations.append("Sampler initial state was not attested; cumulative balance from initialization was not assessed.")
    kind = trace.get("trace_origin", {}).get("kind", "UNSPECIFIED")
    if kind not in {"production_loader", "production_dataset_loader"}:
        limitations.append("Trace is not identified as a real production-loader run; it cannot establish real-data execution.")
    result = {"status": "PASS" if not failure_counts else "FAIL", "scope": "Emitted-index budget audit against independent original-source identity", "trace_origin": trace.get("trace_origin"), "trace_stage": trace.get("trace_stage", "UNSPECIFIED"), "trace_sha256": digest(trace_path.read_bytes()), "oracle_sha256": digest((OUT / "source_oracle.json").read_bytes()), "checker_sha256": digest(Path(__file__).read_bytes()), "sampler_definition_audit_used_as_oracle": False, "inventory_patches": len(inventory), "inventory_patches_by_physical": dict(sorted(inventory_phys.items())), "inventory_patches_by_representation": dict(sorted(inventory_rep.items())), "active_physical_groups_by_scroll": {key: sorted(values) for key, values in sorted(active_physical.items())}, "active_representations_by_physical": {key: sorted(values) for key, values in sorted(active_repr.items())}, "configured_representations_without_training_patches": sorted(configured_references - active_references), "source_representations_not_configured": sorted(source_references - configured_references), "source_representations_not_active": sorted(source_references - active_references), "provenance_checks": provenance_checks, "batches_checked": len(batches), "samples_checked": sum(len(batch["indices"] if isinstance(batch, dict) else batch) for batch in batches), "observed_scroll_counts": dict(sorted(scroll_counts.items())), "observed_physical_counts": dict(sorted(physical_counts.items())), "observed_representation_counts": dict(sorted(repr_counts.items())), "observed_patch_counts": {str(key): value for key, value in sorted(patch_counts.items())}, "batch_boundary_balance_checked_from_initialization": prefix_balance_checked, "failure_counts": dict(failure_counts), "failures": failures, "failure_details_truncated": sum(failure_counts.values()) > len(failures), "limitations": limitations}
    save_json(output, result)
    print(json.dumps({key: result[key] for key in ["status", "trace_origin", "inventory_patches", "batches_checked", "samples_checked", "failure_counts", "batch_boundary_balance_checked_from_initialization"]}, indent=2))


def audit_manifest(manifest_path: Path, output: Path) -> None:
    oracle = read_json(OUT / "source_oracle.json")
    manifest = read_json(manifest_path)
    expected = {row["representation_reference"]: row for row in oracle["rows"]}
    seen = set()
    failures = []
    for row in manifest["representations"]:
        key = row["representation_key"]
        if key in seen:
            failures.append({"kind": "duplicate_representation", "representation": key})
        seen.add(key)
        ref = expected.get(key)
        if ref is None:
            failures.append({"kind": "unbound_representation", "representation": key})
            continue
        if row["segment"] != ref["label_segment"] or row["scroll"] != ref["scroll"]:
            failures.append({"kind": "wrong_label_or_scroll", "representation": key, "observed": row})
        try:
            address = source_address(row["source_link"])
        except (ValueError, KeyError) as exc:
            failures.append({"kind": "invalid_source_link", "representation": key, "error": str(exc)})
            continue
        if address != source_address(ref["source_volume_url"]):
            failures.append({"kind": "wrong_source_frame_or_segment", "representation": key, "expected_source_link": ref["source_volume_url"], "observed_source_link": row["source_link"]})
    missing = sorted(set(expected) - seen)
    if missing:
        failures.append({"kind": "missing_representations", "representations": missing})
    result = {"status": "PASS" if not failures else "FAIL", "scope": "Proposed manifest label, scroll, public segment ID and exact source-frame assignments compared to independently downloaded original README", "manifest_sha256": digest(manifest_path.read_bytes()), "original_readme_sha256": oracle["source_readme_sha256"], "source_oracle_sha256": digest((OUT / "source_oracle.json").read_bytes()), "representations_seen": len(seen), "frames_preserved": sorted({row["source_frame"] for row in oracle["rows"]}), "source_response_hash_comparison": "Not compared: proposed source_response may be HTML; independent original is publisher raw Markdown", "failures": failures, "limit": "Link/identity verification; no pixel equality, geometric registration, label correctness or runtime execution claim"}
    save_json(output, result)
    print(json.dumps({"status": result["status"], "representations_seen": len(seen), "failures": failures}, indent=2))


def audit_label_metadata(output: Path, fetch_critical: bool) -> None:
    oracle = read_json(OUT / "source_oracle.json")
    folder_for_family = {family: folder for folder, family in FAMILIES.items()}
    results, failures, independent_downloads = [], [], []
    for row in oracle["rows"]:
        label, family = row["label_segment"], row["family"]
        release_prefix = f"ink_9um/labels/{folder_for_family[family]}/{label}/{label}_inklabels.zarr"
        local_prefix = ROOT / "evidence/data-access-cache/objects" / release_prefix
        metadata_path = local_prefix / ".zattrs"
        record = {"representation": row["representation_reference"], "public_metadata_url": f"https://huggingface.co/buckets/scrollprize/datasets/resolve/{release_prefix}/.zattrs", "metadata_path": str(metadata_path), "source_reference": row["physical_reference"], "source_frame": row["source_frame"]}
        if not metadata_path.is_file():
            record["status"] = "METADATA_NOT_LOCALLY_AVAILABLE"
            results.append(record)
            continue
        data = metadata_path.read_bytes()
        if len(data) > 64000:
            raise ValueError(f"unexpectedly large label metadata: {metadata_path}")
        metadata = json.loads(data)
        record["bytes"] = len(data)
        record["sha256"] = digest(data)
        receipt_path = local_prefix / ".zattrs.receipt.json"
        if receipt_path.is_file():
            receipt = read_json(receipt_path)
            requested = urlsplit(receipt["url"])
            expected_url = urlsplit(record["public_metadata_url"])
            receipt_match = requested.scheme == "https" and requested.netloc == expected_url.netloc and requested.path == expected_url.path and receipt.get("status") == 200 and receipt.get("bytes") == len(data) and receipt.get("sha256") == digest(data)
            record["recorded_download_receipt_matches_bytes_and_route"] = receipt_match
            if not receipt_match:
                failures.append({"kind": "label_metadata_receipt_mismatch", "representation": row["representation_reference"]})
        else:
            record["recorded_download_receipt_matches_bytes_and_route"] = None
        source_volume = metadata.get("source_surface_volume")
        if source_volume:
            source_match = source_address(source_volume) == source_address(row["source_volume_url"])
            record["explicit_metadata_source_frame_matches_readme"] = source_match
            record["source_surface_volume"] = source_volume
            if not source_match:
                failures.append({"kind": "metadata_source_frame_disagrees_with_readme", "representation": row["representation_reference"]})
        else:
            record["explicit_metadata_source_frame_matches_readme"] = None
            record["identity_evidence_limit"] = "No explicit public source volume/segment ID in this metadata; README remains the identity assignment source"
        record["annotation_center_channel"] = metadata.get("annotation_center_channel")
        record["output_channels"] = metadata.get("output_channels")
        array_path = local_prefix / "0/.zarray"
        if array_path.is_file():
            array = read_json(array_path)
            record["level0_shape"] = array.get("shape")
            record["level0_chunks"] = array.get("chunks")
            if array.get("shape", [None])[0] != row["label_frame"]["depth"]:
                failures.append({"kind": "label_depth_disagrees_with_readme", "representation": row["representation_reference"], "shape": array.get("shape")})
        if family == "public_2p4_level2_zmean4" and (metadata.get("annotation_center_channel") != 10 or metadata.get("output_channels") != 21 or metadata.get("case") != label):
            failures.append({"kind": "aligned_label_frame_or_case_mismatch", "representation": row["representation_reference"]})
        if fetch_critical and row["representation_reference"] in {"public_2p4_level2_zmean4:pherc0139-w028", "native_9p362_level0:w044"}:
            with urlopen(Request(record["public_metadata_url"], headers={"User-Agent": "independent-fixed-prior-audit/1"}), timeout=60) as response:
                downloaded = response.read()
            filename = f"{family}_{label}_inklabels.zattrs.json"
            (ORIGINALS / filename).write_bytes(downloaded)
            independent_match = downloaded == data
            record["independently_refetched_bytes_match"] = independent_match
            independent_downloads.append({"file": filename, "url": record["public_metadata_url"], "bytes": len(downloaded), "sha256": digest(downloaded), "match_root_download": independent_match})
            if not independent_match:
                failures.append({"kind": "independent_label_metadata_bytes_mismatch", "representation": row["representation_reference"]})
        record["status"] = "READ"
        results.append(record)
    result = {"status": "PASS" if not failures else "FAIL", "scope": "Targeted original label metadata and recorded byte/route integrity; no label or CT values decoded and no real loader execution asserted", "original_readme_sha256": oracle["source_readme_sha256"], "metadata_available": sum(row["status"] == "READ" for row in results), "explicit_source_frame_assignments": sum(row.get("explicit_metadata_source_frame_matches_readme") is True for row in results), "metadata_without_explicit_source_volume": [row["representation"] for row in results if row["status"] == "READ" and row.get("explicit_metadata_source_frame_matches_readme") is None], "independently_refetched": independent_downloads, "representations": results, "failures": failures}
    save_json(output, result)
    print(json.dumps({key: result[key] for key in ["status", "metadata_available", "explicit_source_frame_assignments", "metadata_without_explicit_source_volume", "independently_refetched", "failures"]}, indent=2))


def self_check() -> None:
    """Adversarial fixtures validate this checker, never real-data execution."""
    oracle = read_json(OUT / "source_oracle.json")
    base = read_json(ORIGINALS / "aligned21_hybrid_3d2d.json")
    correct = copy.deepcopy(base)
    for row in bind_config(correct, oracle):
        correct["datasets"][row["dataset_idx"]]["sampling_physical_segment_keys"][row["segment_relpath"]] = row["physical_reference"]
    fixtures = OUT / "counterexamples"
    fixtures.mkdir(exist_ok=True)
    configs = {"source_identity": correct, "label_number_split": base}
    volume_url = copy.deepcopy(correct)
    scanframe = copy.deepcopy(correct)
    collision = copy.deepcopy(correct)
    missing = copy.deepcopy(correct)
    for row in bind_config(correct, oracle):
        idx, label = row["dataset_idx"], row["segment_relpath"]
        volume_url["datasets"][idx]["sampling_physical_segment_keys"][label] = row["source_volume_url"]
        scanframe["datasets"][idx]["sampling_physical_segment_keys"][label] = row["scroll"] + ":" + row["source_frame"]
        if label in {"pherc0139-w016", "pherc0139-w029"}:
            collision["datasets"][idx]["sampling_physical_segment_keys"][label] = "0139:w029"
    native = next(dataset for dataset in missing["datasets"] if family_for_path(dataset["segments_path"]) == "native_9p362_level0")
    native["segments"].remove("w044")
    configs.update({"full_volume_url_split": volume_url, "scanframe_overmerge": scanframe, "label_public_number_collision": collision, "drop_native_w044": missing})
    report = []
    for name, config in configs.items():
        config_path = fixtures / f"{name}.json"
        result_path = fixtures / f"{name}_partition_audit.json"
        save_json(config_path, config)
        inspect_config(config_path, result_path)
        result = read_json(result_path)
        expected = "PASS" if name in {"source_identity", "drop_native_w044"} else "FAIL"
        assert result["status"] == expected, (name, result["status"])
        if name == "drop_native_w044":
            assert result["source_representations_not_configured"] == ["native_9p362_level0:w044"]
        report.append({"case": name, "partition_status": result["status"], "source_representations_not_configured": result["source_representations_not_configured"], "failure_kinds": dict(Counter(row["kind"] for row in result["failures"]))})
    for name in ["source_identity", "label_number_split"]:
        config = configs[name]
        rows = bind_config(config, oracle)
        physicals = defaultdict(dict)
        patches = []
        for index, row in enumerate(rows):
            patches.append({"index": index, "dataset_idx": row["dataset_idx"], "segment_relpath": row["segment_relpath"], "is_validation": False, "is_unlabeled": False})
            physicals[row["scroll"]].setdefault(row["configured_physical"], []).append(index)
        cursors, repr_cursors = Counter(), Counter()
        batches = []
        for _ in range(10):
            batch = []
            for scroll, quota in oracle["budget_contract"]["scroll_quotas"].items():
                groups = list(physicals[scroll])
                for _ in range(quota):
                    group = groups[cursors[scroll] % len(groups)]
                    cursors[scroll] += 1
                    choices = physicals[scroll][group]
                    batch.append(choices[repr_cursors[(scroll, group)] % len(choices)])
                    repr_cursors[(scroll, group)] += 1
            batches.append(batch)
        trace = {"trace_origin": {"kind": "adversarial_fixture", "purpose": "checker counterexample only; no scroll data or real loader run"}, "trace_starts_at_sampler_initialization": True, "config": config, "patches": patches, "batches": batches, "definition_audit": {"physical_segments_by_scroll": "forged-but-ignored", "status": "PASS"}}
        trace_path = fixtures / f"{name}_trace.json"
        result_path = fixtures / f"{name}_trace_audit.json"
        save_json(trace_path, trace)
        audit_trace(trace_path, result_path)
        result = read_json(result_path)
        assert result["status"] == ("PASS" if name == "source_identity" else "FAIL")
        assert result["sampler_definition_audit_used_as_oracle"] is False
        report.append({"case": name + "_emitted_indices", "runtime_fixture_status": result["status"], "failure_counts": result["failure_counts"], "definition_audit_ignored": True})
    original_manifest = {"representations": [{"representation_key": row["representation_reference"], "segment": row["label_segment"], "scroll": row["scroll"], "source_link": row["source_volume_url"]} for row in oracle["rows"]]}
    wrong_frame = copy.deepcopy(original_manifest)
    native_row = next(row for row in wrong_frame["representations"] if row["representation_key"] == "native_9p362_level0:w044")
    aligned_ref = next(row for row in oracle["rows"] if row["representation_reference"] == "public_2p4_level2_zmean4:pherc0139-w028")
    native_row["source_link"] = aligned_ref["source_volume_url"]
    rogue_host = copy.deepcopy(original_manifest)
    rogue_host["representations"][0]["source_link"] = rogue_host["representations"][0]["source_link"].replace("vesuvius-challenge-open-data.s3.amazonaws.com", "example.invalid")
    for name, manifest in [("same_segment_wrong_scanframe", wrong_frame), ("rogue_host_same_path", rogue_host)]:
        manifest_path = fixtures / f"{name}.json"
        result_path = fixtures / f"{name}_audit.json"
        save_json(manifest_path, manifest)
        audit_manifest(manifest_path, result_path)
        result = read_json(result_path)
        assert result["status"] == "FAIL"
        report.append({"case": name, "manifest_status": "FAIL", "failure_kinds": dict(Counter(row["kind"] for row in result["failures"]))})
    frame_trace = read_json(fixtures / "source_identity_trace.json")
    aligned_publisher = urlsplit(aligned_ref["source_volume_url"])
    wrong_actual_frame = "https://vesuvius-challenge-open-data.s3.amazonaws.com/" + aligned_publisher.fragment.rstrip("/") + "/"
    frame_trace["source_bindings"] = {"native_9p362_level0:w044": {"original_source_volume_url": wrong_actual_frame}}
    frame_path = fixtures / "same_segment_wrong_scanframe_trace.json"
    frame_output = fixtures / "same_segment_wrong_scanframe_trace_audit.json"
    save_json(frame_path, frame_trace)
    audit_trace(frame_path, frame_output)
    frame_result = read_json(frame_output)
    assert frame_result["failure_counts"] == {"wrong_source_frame_or_segment": 1}
    report.append({"case": "same_segment_wrong_scanframe_emitted_indices", "runtime_fixture_status": "FAIL", "failure_counts": frame_result["failure_counts"]})
    save_json(OUT / "counterexample_audit.json", {"status": "PASS", "scope": "Adversarial fixtures verify checker discrimination; no real loader or real data claim", "cases": report, "analytic_budget_counterexample": {"base_PHerc0139_configured_groups": len(physicals["0139"]), "source_bound_PHerc0139_physical_groups": len(oracle["physical_groups_by_scroll"]["0139"]), "split_w044_budget_fraction": "2/10", "correct_w044_budget_fraction": "1/9", "overweight_ratio": "9/5", "per_64_batch_long_run_split_w044_mass": "29/5", "per_64_batch_long_run_correct_w044_mass": "29/9"}})
    print("Independent checker counterexamples passed; real loader verification remains pending.")


def main() -> None:
    parser = argparse.ArgumentParser(__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("acquire")
    sub.add_parser("oracle")
    sub.add_parser("self-check")
    inspect = sub.add_parser("inspect-config")
    inspect.add_argument("config", type=Path)
    inspect.add_argument("output", type=Path)
    audit = sub.add_parser("audit-trace")
    audit.add_argument("trace", type=Path)
    audit.add_argument("output", type=Path)
    manifest = sub.add_parser("audit-manifest")
    manifest.add_argument("manifest", type=Path)
    manifest.add_argument("output", type=Path)
    metadata = sub.add_parser("audit-label-metadata")
    metadata.add_argument("output", type=Path)
    metadata.add_argument("--fetch-critical", action="store_true")
    args = parser.parse_args()
    if args.command == "acquire":
        acquire()
    elif args.command == "oracle":
        build_oracle()
    elif args.command == "inspect-config":
        inspect_config(args.config, args.output)
    elif args.command == "audit-trace":
        audit_trace(args.trace, args.output)
    elif args.command == "self-check":
        self_check()
    elif args.command == "audit-manifest":
        audit_manifest(args.manifest, args.output)
    elif args.command == "audit-label-metadata":
        audit_label_metadata(args.output, args.fetch_critical)


if __name__ == "__main__":
    main()
