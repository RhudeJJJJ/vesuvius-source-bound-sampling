"""Independent original-mask materialization audit; no runtime code imports.

Reads catalog/receipts through structured JSONL, never prints whole logs.
Checks every retained original byte object and independently decodes each unique
published chunk blob. Missing local chunks require an actual all-fill proof.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "verification"


def digest_file(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text("utf-8"))


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--summary", type=Path, default=ROOT / "runtime/labels-summary.json")
    parser.add_argument("--report", type=Path, default=ROOT / "runtime/data-access-report.json")
    parser.add_argument("--output", type=Path, default=OUT / "original_mask_materialization_audit.json")
    parser.add_argument("--allow-selected-stores", action="store_true", help="audit explicitly bounded priority stores without claiming all29 materialization")
    args = parser.parse_args()
    summary, report = read_json(args.summary), read_json(args.report)
    if summary.get("complete") is not True or summary.get("local_stores_complete") is not True or report.get("listing_complete") is not True:
        raise ValueError("completed original materialization and complete public listing are required")
    receipts_path = resolve(summary["receipts"])
    catalog_path = resolve(report["chunk_manifest"])
    if digest_file(receipts_path) != summary["receipts_sha256"]:
        raise ValueError("materialization receipt bytes changed")
    if digest_file(catalog_path) != report["chunk_manifest_sha256"] or summary["input_manifest_sha256"] != report["chunk_manifest_sha256"]:
        raise ValueError("public catalog reference changed")
    original = read_json(OUT / "source_oracle.json")
    folders = {"public_2p4_level2_zmean4": "aligned-scrollprizeorg-21slices", "native_9p362_level0": "native9-scrollprizeorg-21slices"}
    expected_stores = set()
    for row in original["rows"]:
        prefix = f"ink_9um/labels/{folders[row['family']]}/{row['label_segment']}/{row['label_segment']}"
        expected_stores.update([prefix + "_inklabels.zarr", prefix + "_supervision_mask.zarr"])
        if row["label_segment"] in {"pherc0139-w016", "pherc0814-46527", "pherc1667-w029"}:
            expected_stores.add(prefix + "_validation_mask.zarr")
    original_stores = set(expected_stores)
    if set(report["complete_level0_store_prefixes"]) != original_stores:
        raise ValueError("complete public listing does not preserve every original label/mask/validation store")
    if args.allow_selected_stores:
        selected_stores = set()
        with receipts_path.open("r", encoding="utf-8") as stream:
            for line in stream:
                for path in json.loads(line)["paths"]:
                    selected_stores.add("/".join(path.split("/")[:5]))
        if not selected_stores or not selected_stores <= original_stores:
            raise ValueError("priority receipt store selection is not bound to original catalog")
        expected_stores = selected_stores
    schemas = {}
    for item in report["metadata_objects"]:
        path = item["release_entry"]["path"]
        if path.endswith("/0/.zarray"):
            prefix = path.removesuffix("/0/.zarray")
            if prefix in expected_stores:
                receipt = item["receipt"]
                original_metadata_path = resolve(receipt["path"]).resolve()
                if not original_metadata_path.is_relative_to(ROOT.resolve()):
                    raise ValueError("original array metadata path is outside workspace")
                original_metadata_bytes = original_metadata_path.read_bytes()
                requested = urlsplit(receipt["url"])
                expected_metadata_path = "/buckets/scrollprize/datasets/resolve/" + path
                if receipt.get("status") != 200 or receipt.get("bytes") != len(original_metadata_bytes) or receipt.get("sha256") != hashlib.sha256(original_metadata_bytes).hexdigest() or requested.scheme != "https" or requested.netloc != "huggingface.co" or requested.path != expected_metadata_path:
                    raise ValueError("original array metadata bytes/route binding failed: " + prefix)
                original_schema = json.loads(original_metadata_bytes)
                if original_schema != item["metadata"]:
                    raise ValueError("report decoder schema disagrees with original .zarray bytes: " + prefix)
                schemas[prefix] = original_schema
    if set(schemas) != expected_stores:
        raise ValueError("original per-store level0 array metadata is incomplete")
    for prefix, schema in schemas.items():
        if schema["dtype"] != "|u1" or schema.get("filters") is not None or schema["fill_value"] not in range(256):
            raise ValueError(f"unsupported independently reviewed chunk contract: {prefix}")
        if schema["compressor"] and schema["compressor"]["id"] != "blosc":
            raise ValueError("only original Blosc byte format is supported")
    selected = {}
    catalog_objects = 0
    with catalog_path.open("r", encoding="utf-8") as stream:
        for line in stream:
            item = json.loads(line)
            catalog_objects += 1
            path = item["path"]
            prefix, suffix = path.rsplit("/", 1)
            is_root_metadata = prefix in expected_stores and suffix.startswith(".")
            is_level0 = prefix.removesuffix("/0") in expected_stores and prefix.endswith("/0")
            if not (is_root_metadata or is_level0):
                continue
            if path in selected:
                raise ValueError("duplicate source catalog path: " + path)
            selected[path] = (item["xetHash"], item["size"])
    output_root = resolve(summary["output_root"]).resolve()
    actual_paths = set()
    for prefix in sorted(expected_stores):
        directory = output_root / prefix
        if not directory.is_dir():
            raise ValueError("missing original store directory: " + prefix)
        for current, _, names in os.walk(directory):
            for name in names:
                actual_paths.add((Path(current) / name).relative_to(output_root).as_posix())
        if read_json(directory / "0/.zarray") != schemas[prefix]:
            raise ValueError("local decoder schema differs from byte-bound original metadata: " + prefix)
    extra = sorted(actual_paths - set(selected))
    if extra:
        raise ValueError("local files outside the complete original catalog: " + repr(extra[:10]))
    from numcodecs import Blosc
    seen, blobs, counters, failures = set(), set(), Counter(), []

    def fail(kind, **detail):
        counters["failure:" + kind] += 1
        if len(failures) < 100:
            failures.append({"kind": kind, **detail})

    with receipts_path.open("r", encoding="utf-8") as stream:
        for line in stream:
            proof = json.loads(line)
            xet_hash = proof["xet_hash"]
            if xet_hash in blobs:
                raise ValueError("duplicate unique-blob proof")
            blobs.add(xet_hash)
            blob_path = resolve(proof["receipt"]["path"])
            compressed = blob_path.read_bytes()
            if len(compressed) != proof["bytes"] or hashlib.sha256(compressed).hexdigest() != proof["sha256"]:
                fail("blob_bytes_mismatch", xet_hash=xet_hash)
            receipt = proof["receipt"]
            if receipt.get("sha256") != proof["sha256"] or receipt.get("bytes") != proof["bytes"]:
                fail("receipt_byte_binding", xet_hash=xet_hash)
            if receipt.get("release_xet_hash") != xet_hash and (receipt.get("etag") or "").strip('"') != xet_hash:
                fail("receipt_release_identity", xet_hash=xet_hash)
            requested = urlsplit(receipt["url"])
            if requested.scheme != "https" or requested.netloc != "huggingface.co" or not requested.path.startswith("/buckets/scrollprize/datasets/resolve/"):
                fail("receipt_source_route", xet_hash=xet_hash)
            receipt_relative = requested.path.removeprefix("/buckets/scrollprize/datasets/resolve/")
            if receipt_relative not in proof["paths"]:
                fail("receipt_sample_not_in_published_group", xet_hash=xet_hash)
            chunk_paths = [path for path in proof["paths"] if not path.rsplit("/", 1)[1].startswith(".")]
            fill = False
            if chunk_paths:
                contracts = []
                for path in chunk_paths:
                    schema = schemas[path.rsplit("/0/", 1)[0]]
                    contracts.append((schema["dtype"], tuple(schema["chunks"]), json.dumps(schema["compressor"], sort_keys=True), schema["fill_value"], schema["order"]))
                if any(contract != contracts[0] for contract in contracts):
                    fail("shared_blob_decode_contract", xet_hash=xet_hash)
                schema = schemas[chunk_paths[0].rsplit("/0/", 1)[0]]
                codec_options = dict(schema["compressor"] or {})
                codec_options.pop("id", None)
                decoded = bytes(Blosc(**codec_options).decode(compressed)) if schema["compressor"] else compressed
                if len(decoded) != math.prod(schema["chunks"]):
                    fail("decoded_chunk_size", xet_hash=xet_hash)
                fill = decoded.count(bytes([schema["fill_value"]])) == len(decoded)
                nonzero = len(decoded) - decoded.count(b"\0")
                if fill != proof["all_fill"] or proof.get("decoded_sha256") != hashlib.sha256(decoded).hexdigest() or proof.get("decoded_bytes") != len(decoded) or proof.get("nonzero_count") != nonzero:
                    fail("independent_decoded_proof", xet_hash=xet_hash, independent_all_fill=fill)
                counters["chunk_blobs_independently_decoded"] += 1
                counters["decoded_bytes_checked"] += len(decoded)
                counters["all_fill_blobs" if fill else "positive_blobs"] += 1
            elif proof["all_fill"]:
                fail("metadata_declared_fill", xet_hash=xet_hash)
            for path in proof["paths"]:
                if path in seen:
                    raise ValueError("source object assigned to multiple proofs")
                seen.add(path)
                expected = selected.get(path)
                if expected != (xet_hash, len(compressed)):
                    fail("published_object_assignment", path=path)
                if path in actual_paths:
                    local = output_root / path
                    if local.stat().st_size != len(compressed) or digest_file(local) != proof["sha256"]:
                        fail("retained_original_bytes", path=path)
                    counters["retained_objects_checked"] += 1
                elif not fill:
                    fail("positive_or_metadata_object_absent", path=path)
                else:
                    counters["independently_verified_fill_omissions"] += 1
            counters["unique_blobs_checked"] += 1
    if seen != set(selected):
        fail("catalog_proof_coverage", missing_count=len(set(selected) - seen), extra_count=len(seen - set(selected)))
    if summary["selected_files"] != len(selected) or summary["unique_blobs"] != len(blobs) or summary["omitted_proven_fill_file_count"] != counters["independently_verified_fill_omissions"]:
        fail("producer_summary_counts")
    selected_representations = sorted({"/".join(prefix.split("/")[2:4]) for prefix in expected_stores})
    if summary.get("representation_scope") is not None and summary["representation_scope"] != selected_representations:
        fail("producer_representation_scope", independently_selected=selected_representations)
    result = {
        "status": "PASS" if not failures else "FAIL",
        "scope": ("Bounded original priority stores; no all29 materialization claim" if args.allow_selected_stores else "All29 original selected level0 masks/labels") + ": catalog coverage, retained bytes and independently decoded fill omissions",
        "summary_reference": {"path": str(args.summary), "sha256": digest_file(args.summary)},
        "report_reference": {"path": str(args.report), "sha256": digest_file(args.report)},
        "catalog_reference": {"path": str(catalog_path), "bytes": catalog_path.stat().st_size, "sha256": digest_file(catalog_path)},
        "receipt_reference": {"path": str(receipts_path), "bytes": receipts_path.stat().st_size, "sha256": digest_file(receipts_path)},
        "original_representations": len(original["rows"]), "selected_representation_count": len(selected_representations), "selected_representations": selected_representations, "original_label_mask_validation_stores": len(expected_stores),
        "decoder_schemas_bound_to_original_metadata_bytes": len(schemas),
        "catalog_objects_read": catalog_objects, "selected_published_objects": len(selected), "retained_original_files": len(actual_paths),
        "counts": dict(counters), "failures": failures,
        "limits": ["No CT data or DataLoader tensors were inspected in this endpoint.", "Publisher catalog/receipt identity and reproduced bytes establish the original materialization route; they do not establish label truth or registration accuracy.", "Shared segment source identity does not establish equal pixel supports across different frames.", "Internal technical verification, not external peer review or model/practice gain."]
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", "utf-8")
    print(json.dumps({key: result[key] for key in ["status", "original_representations", "original_label_mask_validation_stores", "selected_published_objects", "retained_original_files", "counts", "failures"]}, indent=2))


if __name__ == "__main__":
    main()
