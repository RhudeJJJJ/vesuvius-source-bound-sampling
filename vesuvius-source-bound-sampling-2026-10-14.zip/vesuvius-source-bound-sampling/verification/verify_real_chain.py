"""Join actual discovery, sampler prefixes, CT coverage and returned tensor hashes.

No runtime/Villa module is imported. Production semantics were read as source;
the bounded flat/robust-MAD transform below is separately executed with NumPy.
"""
from __future__ import annotations
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np
import zarr

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "verification"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def reference(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return {"path": str(path.resolve()), "bytes": path.stat().st_size, "sha256": h.hexdigest()}


def read(path):
    return json.loads(Path(path).read_text("utf-8"))


def robust_mad(crop, lower, upper):
    arr = crop.astype(np.float32, copy=True)
    values = arr.reshape(-1)
    std = float(np.std(values))
    lo, hi = float(np.percentile(values, lower)), float(np.percentile(values, upper))
    np.clip(arr, lo, hi, out=arr)
    median = float(np.median(arr))
    scale = 1.4826 * float(np.median(np.abs(arr - median)))
    if not np.isfinite(scale) or scale < 1e-6:
        scale = next((candidate for candidate in (abs(std), abs(hi - lo) / 2.0)
                      if np.isfinite(candidate) and candidate >= 1e-6), 1.0)
    arr -= median
    arr /= scale
    np.nan_to_num(arr, copy=False, nan=0.0, posinf=0.0, neginf=0.0)
    return arr


def tensor_record(array):
    array = np.ascontiguousarray(array, dtype=np.float32)[None, ...]
    return {"shape": list(array.shape), "dtype": str(array.dtype),
            "finite_count": int(np.isfinite(array).sum()), "elements": int(array.size),
            "nonzero_count": int(np.count_nonzero(array)),
            "minimum": float(array.min()), "maximum": float(array.max()),
            "sha256": digest(array.tobytes(order="C"))}


def main():
    paths = {"discovery": ROOT / "runtime/real-discovery.json",
             "plan": ROOT / "runtime/real-load-plan.json",
             "report": ROOT / "runtime/real-results/real-load-report.json",
             "before": ROOT / "runtime/real-results/before-trace.json",
             "after": ROOT / "runtime/real-results/after-trace.json",
             "ct": ROOT / "evidence/ct-manifest-at-load.json"}
    preimages = {name: reference(path) for name, path in paths.items()}
    data = {name: read(path) for name, path in paths.items()}
    discovery, plan, report, ct = (data[k] for k in ("discovery", "plan", "report", "ct"))
    oracle = read(OUT / "source_oracle.json")
    source = {row["representation_reference"]: row for row in oracle["rows"]}
    failures, checked_refs = [], {}

    def require(condition, kind, **details):
        if not condition:
            failures.append({"kind": kind, **details})

    def check_ref(ref):
        key = ref["path"]
        if key not in checked_refs:
            actual = reference(key)
            require(actual == ref, "artifact_reference_bytes_differ", declared=ref, actual=actual)
            checked_refs[key] = actual

    for field in ("source_manifest", "original_recipe", "ct_manifest_at_discovery"):
        check_ref(discovery[field])
    for field in ("summary", "public_listing", "listing_objects", "receipts"):
        check_ref(discovery["label_provenance"][field])
    for record in [discovery["environment"], report["environment"]] + [data[v]["trace_origin"]["environment"] for v in ("before", "after")]:
        check_ref(record["script"])
        for ref in record["production_sources"]:
            check_ref(ref)
    for variant in ("before", "after"):
        trace = data[variant]
        check_ref(trace["discovery_artifact"])
        check_ref(trace["ct_manifest"])
        check_ref(plan["trace_references"][variant])
        require(trace["patches"] == discovery["patches"], "trace_patch_inventory_drift", variant=variant)
        require(trace["ct_manifest"] == discovery["ct_manifest_at_discovery"], "trace_not_bound_to_frozen_discovery_ct", variant=variant)
        require(trace["trace_starts_at_sampler_initialization"] is True, "missing_initialization_scope", variant=variant)
    check_ref(plan["discovery_artifact"])
    for field in ("discovery", "load_plan", "ct_manifest"):
        check_ref(report[field])
    require(report["ct_manifest"] == preimages["ct"], "loader_ct_snapshot_drift")
    require(report["augmentations"] is False and report["workers"] == 0, "unexpected_payload_transform_or_prefetch")
    require(discovery["config"]["mode"] == "flat", "unsupported_mode")
    norm = discovery["config"]["image_normalization"]
    require(norm["mode"] == "robust_mad", "unsupported_normalization")
    require(discovery["config"]["flat_z_window_jitter"]["window_depth"] == 17, "unexpected_canonical_depth")

    prerequisite_paths = ["original_all29_mask_materialization_audit.json", "final_ct_source_and_tile_audit.json", "real_patch_eligibility_audit.json"]
    prerequisites = {name: read(OUT / name) for name in prerequisite_paths}
    for name, audit in prerequisites.items():
        require(audit["status"] == "PASS", "required_independent_endpoint_failed", audit=name)
    require(prerequisites["final_ct_source_and_tile_audit.json"]["ct_manifest_sha256"] == preimages["ct"]["sha256"], "ct_audit_snapshot_drift")

    inventory = {row["index"]: row for row in discovery["patches"]}
    require(len(inventory) == len(discovery["patches"]), "duplicate_discovery_index")
    count = plan["load_batches_per_variant"]
    require(count == 1, "unexpected_payload_scope")
    chosen = sorted({index for v in ("before", "after") for batch in data[v]["batches"][:count] for index in batch})
    require(plan["patches"] == [inventory[index] for index in chosen], "load_plan_not_exact_emitted_prefix_union")
    require({row["representation_key"] for row in plan["patches"]} == set(source), "load_plan_drops_source_representation")

    # Enumerate requested tiles from geometry, independently of producer preflight.
    preflight, required_tiles = [], set()
    for patch in plan["patches"]:
        rep = patch["representation_key"]
        entry = ct["representations"][rep]
        require(Path(entry["output_store"]).resolve() == Path(patch["image_volume"]).resolve(), "image_asset_differs_from_ct", index=patch["index"])
        shape = entry["output_shape"]
        z0, y0, x0, z1, y1, x1 = patch["bbox"]
        require(0 <= z0 < z1 <= shape[0], "ct_z_outside_real_layers", index=patch["index"])
        tiles = []
        for cy in range(max(0, y0) // 128, (min(shape[1], y1) + 127) // 128):
            for cx in range(max(0, x0) // 128, (min(shape[2], x1) + 127) // 128):
                key = f"{cy}.{cx}"
                expected_bbox = [0, cy * 128, cx * 128, shape[0], min(shape[1], (cy + 1) * 128), min(shape[2], (cx + 1) * 128)]
                completed = entry["completed_tiles"].get(key)
                require(completed is not None and completed["bbox"] == expected_bbox, "UNKNOWN_or_wrong_completed_ct_tile", index=patch["index"], tile=key)
                tiles.append(key)
                required_tiles.add((rep, key))
        preflight.append({"index": patch["index"], "representation_key": rep, "bbox": patch["bbox"], "completed_tiles": tiles})
    require(preflight == report["ct_completed_tile_preflight"], "loader_preflight_not_geometry_exact")
    audited_tiles = {(row["representation"], row["tile"]) for row in prerequisites["final_ct_source_and_tile_audit.json"]["tiles"] if row["values_independently_checked"]}
    require(required_tiles <= audited_tiles, "payload_reads_exceed_independently_checked_ct_tiles")

    arrays, expected_tensors = {}, {}

    def crop(path, bbox):
        if path not in arrays:
            group = zarr.open(path, mode="r")
            arrays[path] = group if hasattr(group, "shape") else group["0"]
        volume = arrays[path]
        starts, stops = bbox[:3], bbox[3:]
        shape = tuple(b - a for a, b in zip(starts, stops))
        out = np.zeros(shape, dtype=volume.dtype)
        clipped_starts = tuple(max(0, a) for a in starts)
        clipped_stops = tuple(min(s, b) for s, b in zip(volume.shape, stops))
        destination = tuple(slice(a - origin, b - origin) for a, b, origin in zip(clipped_starts, clipped_stops, starts))
        src = tuple(slice(a, b) for a, b in zip(clipped_starts, clipped_stops))
        out[destination] = np.asarray(volume[src])
        return out, destination

    for index in chosen:
        patch = inventory[index]
        bbox = patch["bbox"]
        image, valid = crop(patch["image_volume"], bbox)
        image = image.astype(np.float32)
        image[valid] = robust_mad(image[valid], norm["percentile_lower"], norm["percentile_upper"])
        ink, _ = crop(patch["inklabels"], bbox)
        sup, _ = crop(patch["supervision_mask"], bbox)
        if patch["validation_mask"] is not None and not patch["is_validation"]:
            validation, _ = crop(patch["validation_mask"], bbox)
            sup[validation > 0] = 0
        expected_tensors[index] = {"image": tensor_record(image), "inklabels": tensor_record(ink), "supervision_mask": tensor_record(sup)}

    variants, hash_maps = {}, {}
    for variant in ("before", "after"):
        rows = report["variants"][variant]
        observed_scroll, observed_phys, observed_rep = Counter(), Counter(), Counter()
        hash_maps[variant] = {}
        require(len(rows["consumed_batches"]) == count, "consumed_batch_count_drift", variant=variant)
        for number, batch in enumerate(rows["consumed_batches"]):
            require(batch["batch"] == number and batch["indices"] == data[variant]["batches"][number], "consumed_indices_differ_from_emitted_prefix", variant=variant, batch=number)
            require(len(batch["samples"]) == len(batch["indices"]), "sample_position_count_drift", variant=variant)
            for index, sample in zip(batch["indices"], batch["samples"]):
                patch = inventory[index]
                rep = patch["representation_key"]
                require(sample["index"] == index and sample["representation_key"] == rep, "returned_sample_identity_drift", variant=variant, index=index)
                require(sample["tensors"] == expected_tensors[index], "independent_tensor_reconstruction_mismatch", variant=variant, index=index)
                hash_maps[variant][index] = sample["tensors"]
                observed_scroll[source[rep]["scroll"]] += 1
                observed_phys[source[rep]["physical_reference"]] += 1
                observed_rep[rep] += 1
        require(rows["unique_patches_consumed"] == len(hash_maps[variant]), "unique_count_drift", variant=variant)
        require(rows["representations_consumed"] == sorted(observed_rep), "representation_count_drift", variant=variant)
        require(dict(observed_scroll) == oracle["budget_contract"]["scroll_quotas"], "consumed_scroll_budget_drift", variant=variant)
        variants[variant] = {"batches": count, "samples": sum(observed_scroll.values()), "unique_patches": len(hash_maps[variant]), "representations": len(observed_rep), "scroll_counts": dict(sorted(observed_scroll.items())), "physical_counts": dict(sorted(observed_phys.items())), "representation_counts": dict(sorted(observed_rep.items()))}
    common = sorted(hash_maps["before"].keys() & hash_maps["after"].keys())
    equality = all(hash_maps["before"][i] == hash_maps["after"][i] for i in common)
    require(report["shared_indices_tensor_hash_equality"] == {"checked": len(common), "indices": common, "equal": equality}, "shared_tensor_hash_claim_drift")
    for name, path in paths.items():
        require(reference(path) == preimages[name], "artifact_changed_during_audit", artifact=name)

    result = {"status": "PASS" if not failures else "FAIL", "scope": "Independent internal join of supplied actual runtime records, original-mask proofs, original CT reconstruction and separately reconstructed returned tensor hashes",
              "inputs": preimages, "artifact_references_checked": list(checked_refs.values()),
              "oracle_reference": reference(OUT / "source_oracle.json"), "checker_reference": reference(__file__),
              "prerequisites": {name: reference(OUT / name) for name in prerequisite_paths},
              "selected_discovery_patches": len(inventory), "selected_discovery_representations": len(discovery["representations"]),
              "reported_full_training_discovery_count": sum(row["training_discovered"] for row in discovery["representations"]),
              "full_discovery_counts_independently_replayed": False,
              "loader_union_unique_patches": len(chosen), "loader_union_representations": len({inventory[i]["representation_key"] for i in chosen}),
              "required_payload_ct_tiles": len(required_tiles), "independently_checked_completed_ct_tiles": len(audited_tiles),
              "independently_reconstructed_unique_tensor_triples": len(expected_tensors), "variants": variants,
              "shared_patch_indices": common, "same_patch_tensor_hashes_equal": equality,
              "negative_ink_unique_patches": sorted(i for i, values in expected_tensors.items() if values["inklabels"]["nonzero_count"] == 0),
              "failures": failures,
              "limits": ["Only one actual 64-sample batch per variant was consumed; 90-batch traces measure sampler emission separately.",
                         "First-four selection/full discovery counts and order were not independently replayed; all selected crop eligibility was checked separately.",
                         "Hashes join records to bytes and transformations; they do not independently observe the producer process.",
                         "Same patch index compares the same frame and coordinates; shared publisher segment grouping does not establish cross-frame pixel equality or registration accuracy.",
                         "Unprepared CT canvas tiles remain UNKNOWN; only completed source-backed payload tiles were read.",
                         "No training/score/model benefit, external review/use or causal Aletheion benefit was established."]}
    destination = OUT / "real_chain_and_tensor_audit.json"
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in ("status", "loader_union_unique_patches", "loader_union_representations", "required_payload_ct_tiles", "independently_reconstructed_unique_tensor_triples", "same_patch_tensor_hashes_equal", "failures")}, indent=2))


if __name__ == "__main__":
    main()
