"""Source-bound CT metadata/chunk/tile audit, independent of runtime modules."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "verification"
CACHE = ROOT / "runtime/ct-source-cache"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text("utf-8"))


def source_address(url):
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.netloc != "vesuvius-challenge-open-data.s3.amazonaws.com":
        raise ValueError("CT source is outside the original public host")
    if parsed.fragment and parsed.path != "/index.html":
        raise ValueError("a publisher fragment may only belong to the original index.html reference")
    return unquote(parsed.fragment or parsed.path).strip("/")


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--manifest", type=Path, default=ROOT / "runtime/ct-manifest.json")
    parser.add_argument("--output", type=Path, default=OUT / "ct_source_artifact_audit.json")
    parser.add_argument("--verify-tiles", action="store_true")
    args = parser.parse_args()
    manifest_bytes = args.manifest.read_bytes()
    state = json.loads(manifest_bytes)
    oracle = read_json(OUT / "source_oracle.json")
    expected = {row["representation_reference"]: row for row in oracle["rows"]}
    if set(state["representations"]) != set(expected):
        raise ValueError("CT metadata does not retain every original representation")
    counters, failures, checked_representations, tile_results = Counter(), [], [], []

    def fail(kind, **details):
        counters["failure:" + kind] += 1
        if len(failures) < 100:
            failures.append({"kind": kind, **details})

    def original_bytes(url):
        record = state["source_objects"].get(url)
        cache_path = CACHE / "bytes" / digest(url.encode())
        if record is None or not cache_path.is_file():
            fail("original_source_object_missing", url=url)
            return None
        raw = cache_path.read_bytes()
        if record.get("url") != url or record.get("status") != 200 or record.get("bytes") != len(raw) or record.get("sha256") != digest(raw):
            fail("source_object_receipt_or_bytes", url=url)
        counters["source_object_byte_reads_checked"] += 1
        return raw

    if args.verify_tiles:
        import numpy as np
        import zarr
    for representation, entry in sorted(state["representations"].items()):
        row = expected[representation]
        expected_address = source_address(row["source_volume_url"])
        url = entry["original_source_volume_url"]
        actual_address = urlsplit(url)
        if actual_address.fragment or actual_address.query or actual_address.path == "/index.html":
            fail("actual_source_fetch_url_not_canonical", representation=representation)
        if source_address(url) != expected_address:
            fail("source_frame_or_segment_disagrees_with_independent_original", representation=representation)
        aligned = row["family"] == "public_2p4_level2_zmean4"
        level = "2" if aligned else "0"
        if entry["source_level"] != level:
            fail("source_level", representation=representation)
        schema_url = url.rstrip("/") + "/" + level + "/.zarray"
        attrs_url = url.rstrip("/") + "/.zattrs"
        raw_schema = original_bytes(schema_url)
        raw_attrs = original_bytes(attrs_url)
        schema = entry["source_schema"]
        if raw_schema is not None and json.loads(raw_schema) != schema:
            fail("recorded_actual_source_schema", representation=representation)
        if raw_attrs is not None and json.loads(raw_attrs) != entry["source_attributes"]:
            fail("recorded_actual_source_attributes", representation=representation)
        shape, chunks = schema["shape"], schema["chunks"]
        if schema["dtype"] != "|u1" or len(shape) != 3 or len(chunks) != 3:
            fail("actual_source_array_contract", representation=representation)
        output_shape = [21, *shape[1:]] if aligned else list(shape)
        if output_shape != entry["output_shape"] or output_shape[0] != row["label_frame"]["depth"]:
            fail("output_label_depth_or_shape", representation=representation)
        folder = "aligned-scrollprizeorg-21slices" if aligned else "native9-scrollprizeorg-21slices"
        label = row["label_segment"]
        label_prefix = ROOT / f"evidence/data-access-cache/objects/ink_9um/labels/{folder}/{label}/{label}_supervision_mask.zarr"
        label_schema = read_json(label_prefix / "0/.zarray")
        if output_shape != label_schema["shape"]:
            fail("actual_source_released_label_canvas", representation=representation)
        z0 = (shape[0] - 84 + 1) // 2 if aligned else 0
        z1 = z0 + 84 if aligned else shape[0]
        if aligned:
            label_attrs = read_json(label_prefix / ".zattrs")
            checks = {"source_surface_volume": source_address(label_attrs["source_surface_volume"]) == source_address(url), "source_surface_volume_level": str(label_attrs["source_surface_volume_level"]) == level, "source_shape_zyx": label_attrs["source_shape_zyx"] == shape, "source_z_slice": label_attrs["source_z_slice"] == [z0, z1]}
            if not all(checks.values()):
                fail("actual_source_aligned_metadata_contract", representation=representation, checks=checks)
        output_store = Path(entry["output_store"])
        output_schema = read_json(output_store / "0/.zarray")
        if output_schema["shape"] != output_shape or output_schema["dtype"] != "|u1" or output_schema["chunks"] != [output_shape[0], 128, 128]:
            fail("actual_output_schema", representation=representation)
        output_attrs = read_json(output_store / ".zattrs")
        if output_attrs.get("source") != url or str(output_attrs.get("source_level")) != level or output_attrs.get("source_shape_zyx") != shape:
            fail("actual_output_source_attribute_binding", representation=representation)
        if output_attrs.get("bounded_validation_store") is not True or "UNKNOWN" not in str(output_attrs.get("unpopulated_tiles", "")).upper():
            fail("actual_output_unknown_tile_warnings", representation=representation)
        source_dir = CACHE / "stores" / digest(representation.encode())[:16] / level
        if entry["completed_tiles"]:
            cached_schema_path = source_dir / ".zarray"
            if not cached_schema_path.is_file() or read_json(cached_schema_path) != schema:
                fail("local_decoder_schema_disagrees_with_original", representation=representation)
        if args.verify_tiles and entry["completed_tiles"]:
            source = zarr.open_array(str(source_dir), mode="r")
            output = zarr.open_group(str(output_store), mode="r")["0"]
        for key, tile in sorted(entry["completed_tiles"].items()):
            cy, cx = [int(value) for value in key.split(".")]
            y0, y1 = cy * 128, min((cy + 1) * 128, shape[1])
            x0, x1 = cx * 128, min((cx + 1) * 128, shape[2])
            if cy < 0 or cx < 0 or y1 <= y0 or x1 <= x0:
                fail("completed_tile_outside_original_canvas", representation=representation, tile=key)
            expected_bbox = [0, y0, x0, output_shape[0], y1, x1]
            expected_source_bbox = [z0, y0, x0, z1, y1, x1]
            if tile["bbox"] != expected_bbox or tile["source_bbox"] != expected_source_bbox:
                fail("completed_tile_geometry", representation=representation, tile=key)
            coords = itertools.product(range(z0 // chunks[0], (z1 + chunks[0] - 1) // chunks[0]), range(y0 // chunks[1], (y1 + chunks[1] - 1) // chunks[1]), range(x0 // chunks[2], (x1 + chunks[2] - 1) // chunks[2]))
            required_urls = {}
            for coord in coords:
                chunk_key = schema.get("dimension_separator", ".").join(map(str, coord))
                chunk_url = url.rstrip("/") + "/" + level + "/" + chunk_key
                required_urls[chunk_url] = chunk_key
            if len(tile["source_chunk_urls"]) != len(required_urls) or set(tile["source_chunk_urls"]) != set(required_urls):
                fail("incomplete_or_extra_original_chunk_coverage", representation=representation, tile=key)
            for chunk_url, chunk_key in required_urls.items():
                raw_chunk = original_bytes(chunk_url)
                local_path = source_dir / chunk_key
                if raw_chunk is not None and (not local_path.is_file() or local_path.read_bytes() != raw_chunk):
                    fail("cached_original_chunk_bytes", representation=representation, tile=key, chunk=chunk_key)
            tile_result = {"representation": representation, "tile": key, "required_source_chunks": len(required_urls), "source_bbox": expected_source_bbox, "output_bbox": expected_bbox, "values_independently_checked": args.verify_tiles}
            if args.verify_tiles:
                block = np.asarray(source[z0:z1, y0:y1, x0:x1])
                if aligned:
                    sums = block.reshape(21, 4, y1-y0, x1-x0).sum(axis=1, dtype=np.uint16)
                    quotients, remainders = sums // 4, sums % 4
                    round_up = (remainders > 2) | ((remainders == 2) & ((quotients % 2) == 1))
                    independently_prepared = (quotients + round_up).astype(np.uint8)
                else:
                    independently_prepared = block
                actual = np.asarray(output[:, y0:y1, x0:x1])
                actual_hash = digest(actual.tobytes(order="C"))
                independent_hash = digest(independently_prepared.tobytes(order="C"))
                if actual_hash != independent_hash or actual_hash != tile["decoded_sha256"] or not np.array_equal(actual, independently_prepared):
                    fail("independent_original_ct_arithmetic_or_output_bytes", representation=representation, tile=key)
                tile_result.update({"independent_integer_half_even_sha256": independent_hash, "actual_output_sha256": actual_hash, "nonzero_voxels": int(np.count_nonzero(actual))})
                counters["decoded_output_tiles_checked"] += 1
            tile_results.append(tile_result)
            counters["completed_tile_source_coverage_checked"] += 1
        checked_representations.append({"representation": representation, "source_volume_url": url, "source_level": level, "source_shape": shape, "output_shape": output_shape, "source_z_slice": [z0, z1], "completed_tiles": len(entry["completed_tiles"]), "native_identity_limit": None if aligned else "Publisher README supplies the public source identity; native label metadata does not independently state that ID"})
    if args.manifest.read_bytes() != manifest_bytes:
        fail("manifest_changed_during_audit")
    result = {"status": "PASS" if not failures else "FAIL", "scope": "Original source frame metadata, source-chunk coverage and receipts" + (" plus independently reconstructed output tiles with exact integer half-even arithmetic" if args.verify_tiles else "; decoded values not checked in this endpoint"), "ct_manifest_sha256": digest(manifest_bytes), "source_oracle_sha256": digest((OUT / "source_oracle.json").read_bytes()), "representations": checked_representations, "tiles": tile_results, "counts": dict(counters), "failures": failures, "limits": ["Only completed output tiles are audited; all other local sparse output tiles remain UNKNOWN, not established zero.", "This is a bounded preparation audit, not a complete production preparation CLI run.", "No cross-frame pixel equality, label correctness, model gain, external peer review or causal Aletheion gain is inferred."]}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", "utf-8")
    print(json.dumps({"status": result["status"], "representations": len(checked_representations), "counts": dict(counters), "failures": failures}, indent=2))


if __name__ == "__main__":
    main()
