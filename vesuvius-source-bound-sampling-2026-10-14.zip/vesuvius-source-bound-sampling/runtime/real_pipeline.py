#!/usr/bin/env python3
"""Bounded real-scroll discovery, production sampling, and real DataLoader reads.

No models are trained. Unknown unpopulated CT tiles are rejected before reads.
All 29 released representations remain configured and must have real patches.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys


ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "vendor/villa/vesuvius"
CONFIGS = VENDOR / "src/vesuvius/ink_detection/configs"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def reference(path):
    path = Path(path).resolve()
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest(path)}


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".partial")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def log(stage, **values):
    print(json.dumps({"stage": stage, **values}), flush=True)


def production():
    # Ordinary source-package imports; no AST extraction or mock modules.
    sys.path.insert(0, str(VENDOR / "src"))
    import numpy as np
    import torch
    from torch.utils.data import DataLoader
    from vesuvius.ink_detection.config import TrainingConfig, resolve_training_mapping
    from vesuvius.ink_detection.data.dataset import InkDataset
    from vesuvius.ink_detection.data.patch_finding_default import find_segment_patches
    from vesuvius.ink_detection.data.segment import gather_segments
    from vesuvius.ink_detection.training.samplers import FixedScrollPriorStratifiedBatchSampler
    from vesuvius.ink_detection.training.train import training_dataset_config
    from vesuvius.ink_detection.types import Patch
    from vesuvius.ink_detection.volume_io import open_volume
    return locals()


def environment(api):
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": api["torch"].__version__,
        "numpy": api["np"].__version__,
        "script": reference(__file__),
        "production_sources": [reference(VENDOR / "src/vesuvius/ink_detection" / path) for path in (
            "config.py", "types.py", "data/dataset.py", "data/segment.py",
            "data/patch_finding_default.py", "training/samplers.py", "volume_io.py",
        )],
    }


def label_gate(args):
    summary, report = read_json(args.label_summary), read_json(args.label_report)
    if summary.get("complete") is not True or report.get("listing_complete") is not True:
        raise ValueError("real mask discovery requires a complete label materialization and public listing")
    if summary.get("input_manifest_sha256") != report.get("chunk_manifest_sha256"):
        raise ValueError("label materialization refers to a different public chunk listing")
    receipts = Path(summary["receipts"])
    if digest(receipts) != summary["receipts_sha256"]:
        raise ValueError("label materialization receipt bytes changed")
    chunk_manifest = Path(report["chunk_manifest"])
    if digest(chunk_manifest) != report["chunk_manifest_sha256"]:
        raise ValueError("public chunk listing bytes changed")
    output = Path(summary["output_root"]).resolve()
    if not args.data_root.resolve().is_relative_to(output):
        raise ValueError("relocated labels are outside the verified materialization output")
    return {
        "summary": reference(args.label_summary), "public_listing": reference(args.label_report),
        "listing_objects": reference(chunk_manifest), "receipts": reference(receipts),
        "materialization": summary,
        "scope": "Complete selected original level-0 label stores; omitted local fill chunks have recorded decoded-fill proofs, not assumed zeros.",
    }


def relocated_config(args, ct):
    authored = read_json(args.config)
    source = read_json(args.source_manifest)
    known = {row["representation_key"]: row for row in source["representations"]}
    observed = set()
    for dataset in authored["datasets"]:
        dataset["segments_path"] = dataset["segments_path"].replace("/path/to/ink_9um", str(args.data_root.resolve()))
        for segment in dataset["segments"]:
            rep = dataset["sampling_representation_keys"][segment]
            entry = ct["representations"][rep]
            expected_url = "https://vesuvius-challenge-open-data.s3.amazonaws.com/" + known[rep]["source_link"].split("#", 1)[1]
            if entry["original_source_volume_url"] != expected_url:
                raise ValueError("actual CT source URL disagrees with separately recorded publisher row: " + rep)
            dataset["surface_volume_paths"][segment] = str(Path(entry["output_store"]).resolve())
            observed.add(rep)
    if observed != set(known) or len(observed) != 29:
        raise ValueError("this experiment requires exactly all 29 released representations")
    authored["out_dir"] = str((args.output_dir / "production-output").resolve())
    authored["dataloader_workers"] = 1
    return authored


def data_config(api, authored):
    training = api["TrainingConfig"].from_mapping(api["resolve_training_mapping"](authored))
    return training, api["training_dataset_config"](training)


def patch_record(index, patch):
    source = patch.segment.source
    return {
        "index": index, "dataset_idx": patch.segment.dataset_idx,
        "segment_relpath": patch.segment.segment_relpath,
        "representation_key": source.sampling_representation_keys[patch.segment.segment_relpath],
        "bbox": list(patch.bbox), "image_volume": str(patch.image_volume),
        "inklabels": str(patch.inklabels), "supervision_mask": str(patch.supervision_mask),
        "validation_mask": None if patch.segment.validation_mask is None else str(patch.segment.validation_mask),
        "is_validation": patch.is_validation, "is_unlabeled": patch.is_unlabeled,
    }


def discover(args, api):
    labels = label_gate(args)
    ct = read_json(args.ct_manifest)
    authored = relocated_config(args, ct)
    training, config = data_config(api, authored)
    if config.patch_finding.kind != "default" or config.discovery_mode != "labeled":
        raise ValueError("this reproduction uses the released default labeled patch finder")
    segments = list(api["gather_segments"](config))
    expected = {(index, name) for index, source in enumerate(config.datasets) for name in source.segment_names}
    if {(segment.dataset_idx, segment.segment_relpath) for segment in segments} != expected:
        raise ValueError("production segment discovery did not retain every configured representation")
    reader = api["InkDataset"](config, patches=[], segments=segments, do_augmentations=False)
    inventory, counts = [], []
    for number, segment in enumerate(segments, start=1):
        training_patches, validation = api["find_segment_patches"](segment, reader._open)
        selected = training_patches if args.patches_per_representation == 0 else training_patches[:args.patches_per_representation]
        if not selected:
            raise ValueError("configured representation has no genuine training patches: " + segment.segment_relpath)
        if len({patch.bbox for patch in selected}) != len(selected):
            raise ValueError("production discovery produced duplicate selected crop identities")
        rep = segment.source.sampling_representation_keys[segment.segment_relpath]
        base_index = len(inventory)
        inventory.extend(patch_record(base_index + offset, patch) for offset, patch in enumerate(selected))
        counts.append({
            "representation_key": rep, "training_discovered": len(training_patches),
            "validation_discovered": len(validation), "selected_training": len(selected),
            "image_shape": list(reader._open(segment.image_volume, segment.scale).shape),
            "inklabels_shape": list(reader._open(segment.inklabels, segment.scale).shape),
            "supervision_shape": list(reader._open(segment.supervision_mask, segment.scale).shape),
        })
        log("discover", representation=rep, completed=number, total=len(segments), **counts[-1])
    if len(inventory) < training.batch_size:
        raise ValueError("bounded genuine pool has fewer patches than one released batch; raise --patches-per-representation")
    result = {
        "kind": "production_real_mask_patch_discovery", "created_at": datetime.now(timezone.utc).isoformat(),
        "environment": environment(api), "config": authored,
        "source_manifest": reference(args.source_manifest), "original_recipe": reference(args.config),
        "label_provenance": labels, "ct_manifest_at_discovery": reference(args.ct_manifest),
        "selection": {"kind": "first_actual_training_patches_per_representation", "limit": args.patches_per_representation, "zero_means_full_real_pool": True},
        "representations": counts, "patches": inventory,
        "boundaries": ["Image arrays were opened for original full-canvas shape metadata; CT voxel reads did not occur in discovery.", "The real released level-0 masks and labels determine the production patch inventory.", "The selected real pool is bounded; it is not the full training corpus unless limit is zero.", "No training, model-quality, pixel-correspondence, external-review or Aletheion-effect claim."],
    }
    write_json(args.discovery, result)
    log("discover_complete", representations=len(counts), genuine_pool_patches=len(inventory), output=str(args.discovery))


def variants(discovery):
    after = deepcopy(discovery["config"])
    before = deepcopy(after)
    matches = 0
    for dataset in before["datasets"]:
        if "pherc0139-w028" in dataset["segments"]:
            if dataset["sampling_physical_segment_keys"]["pherc0139-w028"] != "0139:w044":
                raise ValueError("input corrected recipe does not contain the selected alias fix")
            dataset["sampling_physical_segment_keys"]["pherc0139-w028"] = "0139:w028"
            matches += 1
    if matches != 1:
        raise ValueError("expected exactly one selected physical-key correction")
    return {"before": before, "after": after}


def ct_binding_gate(discovery, ct):
    ref = discovery["source_manifest"]
    if reference(ref["path"]) != ref:
        raise ValueError("separate publisher source manifest changed after discovery")
    for row in read_json(ref["path"])["representations"]:
        rep = row["representation_key"]
        expected = "https://vesuvius-challenge-open-data.s3.amazonaws.com/" + row["source_link"].split("#", 1)[1]
        if ct["representations"][rep]["original_source_volume_url"] != expected:
            raise ValueError("actual CT source frame differs from separately recorded publisher row: " + rep)


def reconstructed_dataset(api, authored, records):
    training, config = data_config(api, authored)
    segments = list(api["gather_segments"](config))
    bound = {(segment.dataset_idx, segment.segment_relpath): segment for segment in segments}
    patches = []
    for expected_index, row in enumerate(records):
        if row["index"] != expected_index or row["is_validation"] or row["is_unlabeled"]:
            raise ValueError("inventory must be a contiguous list of genuine training patches")
        segment = bound[(row["dataset_idx"], row["segment_relpath"])]
        patch = api["Patch"](segment=segment, bbox=tuple(row["bbox"]))
        if patch_record(expected_index, patch) != row:
            raise ValueError("patch assets or identity differ from production discovery")
        patches.append(patch)
    dataset = api["InkDataset"](config, patches=patches, segments=segments, do_augmentations=False)
    return training, config, dataset


def sampler_batches(sampler, count):
    result, epochs = [], 0
    # Reusing this same sampler retains every queue across natural epoch boundaries.
    while len(result) < count:
        epochs += 1
        for indices in sampler:
            result.append([int(index) for index in indices])
            if len(result) == count:
                return result, epochs
    return result, epochs


def source_bindings(ct):
    return {rep: {
        "original_source_volume_url": row["original_source_volume_url"],
        "source_level": row["source_level"], "output_store": row["output_store"],
        "source_schema": row["source_schema"],
    } for rep, row in ct["representations"].items()}


def sample(args, api):
    discovery, ct = read_json(args.discovery), read_json(args.ct_manifest)
    ct_binding_gate(discovery, ct)
    for label, authored in variants(discovery).items():
        training, config, dataset = reconstructed_dataset(api, authored, discovery["patches"])
        sampler = api["FixedScrollPriorStratifiedBatchSampler"](dataset.patches, config, batch_size=training.batch_size)
        loader = api["DataLoader"](dataset, batch_sampler=sampler, num_workers=0, pin_memory=False)
        batches, epochs = sampler_batches(loader.batch_sampler, args.batches)
        trace = {
            "config": authored, "patches": discovery["patches"], "batches": batches,
            "trace_origin": {"kind": "production_dataset_loader", "method": "ordinary imported production InkDataset and FixedScrollPriorStratifiedBatchSampler attached to DataLoader; emitted indices collected from its batch_sampler", "payloads_consumed_in_this_stage": False, "environment": environment(api)},
            "trace_stage": "sampler_to_dataloader", "trace_starts_at_sampler_initialization": True,
            "natural_loader_epochs_entered": epochs, "source_bindings": source_bindings(ct),
            "discovery_artifact": reference(args.discovery), "ct_manifest": reference(args.ct_manifest),
            "definition_audit": sampler.definition_audit(), "observed_audit": sampler.observed_audit(),
            "scope": "Production sampling on a bounded original-mask-derived real patch pool; CT payload consumption is a separately measured subset.",
        }
        path = args.output_dir / f"{label}-trace.json"
        write_json(path, trace)
        log("sample_complete", variant=label, batches=len(batches), samples=sum(map(len, batches)), output=str(path))


def planned_patches(discovery, traces, count):
    inventory = {row["index"]: row for row in discovery["patches"]}
    if count <= 0 or any(len(trace["batches"]) < count for trace in traces.values()):
        raise ValueError("load-batches must be a positive available sampler prefix")
    chosen = sorted({index for trace in traces.values() for batch in trace["batches"][:count] for index in batch})
    return [inventory[index] for index in chosen]


def plan_load(args):
    discovery = read_json(args.discovery)
    traces = {label: read_json(args.output_dir / f"{label}-trace.json") for label in ("before", "after")}
    selected = planned_patches(discovery, traces, args.load_batches)
    plan = {
        "kind": "actual_initial_sampler_batches_load_plan", "load_batches_per_variant": args.load_batches,
        "patches": selected,
        "trace_references": {label: reference(args.output_dir / f"{label}-trace.json") for label in traces},
        "discovery_artifact": reference(args.discovery),
        "scope": "Deduplized union of actual before/after initial sampler batch indices; no patch duplication or invented crop.",
    }
    write_json(args.load_plan, plan)
    log("plan_load_complete", unique_genuine_patches=len(selected), representations=len({row["representation_key"] for row in selected}), output=str(args.load_plan))


def preflight_ct(plan, ct, api):
    checked, tile_hashes, arrays = [], {}, {}
    for patch in plan["patches"]:
        entry = ct["representations"][patch["representation_key"]]
        if Path(entry["output_store"]).resolve() != Path(patch["image_volume"]).resolve():
            raise ValueError("CT output store differs from discovered patch image")
        shape = entry["output_shape"]
        z0, y0, x0, z1, y1, x1 = patch["bbox"]
        if z0 < 0 or z1 > shape[0]:
            raise ValueError("real-layer crop exceeds CT Z bounds")
        requested = []
        for cy in range(max(0, y0) // 128, (min(shape[1], y1) + 127) // 128):
            for cx in range(max(0, x0) // 128, (min(shape[2], x1) + 127) // 128):
                key = f"{cy}.{cx}"
                tile = entry["completed_tiles"].get(key)
                expected = [0, cy * 128, cx * 128, shape[0], min(shape[1], (cy + 1) * 128), min(shape[2], (cx + 1) * 128)]
                if tile is None or tile["bbox"] != expected or not tile.get("decoded_sha256"):
                    raise ValueError(f"UNKNOWN CT tile cannot be read: {patch['representation_key']} tile={key}")
                identity = patch["representation_key"], key
                if identity not in tile_hashes:
                    array = arrays.get(patch["representation_key"])
                    if array is None:
                        array = api["open_volume"](entry["output_store"], 0)
                        arrays[patch["representation_key"]] = array
                    _, ty0, tx0, tz1, ty1, tx1 = expected
                    decoded = api["np"].asarray(array[0:tz1, ty0:ty1, tx0:tx1])
                    actual_hash = hashlib.sha256(decoded.tobytes(order="C")).hexdigest()
                    if actual_hash != tile["decoded_sha256"]:
                        raise ValueError(f"completed CT tile bytes changed or are absent: {identity}")
                    tile_hashes[identity] = actual_hash
                requested.append(key)
        if not requested:
            raise ValueError("real CT crop has no in-canvas content")
        checked.append({"index": patch["index"], "representation_key": patch["representation_key"], "bbox": patch["bbox"], "completed_tiles": requested})
    return checked


def tensor_record(api, tensor):
    array = tensor.detach().cpu().contiguous().numpy()
    finite = api["np"].isfinite(array)
    return {"shape": list(array.shape), "dtype": str(array.dtype), "finite_count": int(finite.sum()),
            "elements": int(array.size), "nonzero_count": int(api["np"].count_nonzero(array)),
            "minimum": float(array.min()), "maximum": float(array.max()),
            "sha256": hashlib.sha256(array.tobytes(order="C")).hexdigest()}


def load(args, api):
    discovery, plan, ct = read_json(args.discovery), read_json(args.load_plan), read_json(args.ct_manifest)
    if reference(args.discovery) != plan["discovery_artifact"]:
        raise ValueError("discovery changed after creating the CT load plan")
    ct_binding_gate(discovery, ct)
    traces = {label: read_json(args.output_dir / f"{label}-trace.json") for label in ("before", "after")}
    if plan["patches"] != planned_patches(discovery, traces, plan["load_batches_per_variant"]):
        raise ValueError("CT load plan no longer matches the genuine sampler prefix crop identities")
    preflight = preflight_ct(plan, ct, api)
    by_variant, hash_maps = {}, {}
    for label, authored in variants(discovery).items():
        if reference(args.output_dir / f"{label}-trace.json") != plan["trace_references"][label]:
            raise ValueError("sampler trace changed after planning reads")
        training, config, dataset = reconstructed_dataset(api, authored, discovery["patches"])
        sampler = api["FixedScrollPriorStratifiedBatchSampler"](dataset.patches, config, batch_size=training.batch_size)
        consumed, per_index, emitted = [], {}, []
        def record_indices():
            count = 0
            while count < plan["load_batches_per_variant"]:
                for indices in sampler:
                    emitted.append([int(index) for index in indices])
                    count += 1
                    yield indices
                    if count == plan["load_batches_per_variant"]:
                        return
        # This generator records the actual sampler-to-loader boundary, without
        # altering any emitted index or queue. Payloads use the production dataset.
        loader = api["DataLoader"](dataset, batch_sampler=record_indices(), num_workers=0, pin_memory=False)
        iterator = iter(loader)
        for number in range(plan["load_batches_per_variant"]):
            batch = next(iterator)
            indices = emitted[number]
            if indices != traces[label]["batches"][number]:
                raise ValueError("actual DataLoader indices disagree with separately recorded initial sampler prefix")
            sample_rows = []
            for position, index in enumerate(indices):
                values = {key: tensor_record(api, batch[key][position]) for key in ("image", "inklabels", "supervision_mask")}
                if any(value["finite_count"] != value["elements"] for value in values.values()):
                    raise ValueError("nonfinite real DataLoader sample")
                if values["image"]["nonzero_count"] == 0 or values["supervision_mask"]["nonzero_count"] == 0:
                    raise ValueError("real DataLoader image or supervision is empty; do not treat unknown data as zeros")
                if index in per_index and per_index[index] != values:
                    raise ValueError("deterministic crop values changed on repeated real-patch read")
                per_index[index] = values
                sample_rows.append({"index": index, "representation_key": discovery["patches"][index]["representation_key"], "tensors": values})
            consumed.append({"batch": number, "indices": indices, "samples": sample_rows})
            log("load_batch", variant=label, batch=number, actual_samples=len(indices), finite=True)
        hash_maps[label] = per_index
        by_variant[label] = {"consumed_batches": consumed, "unique_patches_consumed": len(per_index),
                             "representations_consumed": sorted({discovery["patches"][index]["representation_key"] for index in per_index})}
    common = sorted(hash_maps["before"].keys() & hash_maps["after"].keys())
    if any(hash_maps["before"][index] != hash_maps["after"][index] for index in common):
        raise ValueError("shared real patch crop changed under the physical-key-only correction")
    result = {
        "kind": "production_real_dataloader_consumption", "environment": environment(api),
        "discovery": reference(args.discovery), "load_plan": reference(args.load_plan), "ct_manifest": reference(args.ct_manifest),
        "ct_completed_tile_preflight": preflight, "augmentations": False, "workers": 0,
        "variants": by_variant, "shared_indices_tensor_hash_equality": {"checked": len(common), "indices": common, "equal": True},
        "boundaries": ["Only the explicitly consumed initial DataLoader batches establish real CT payload execution.", "The longer 90-batch trace is a separate sampler emission measurement on the same real discovered pool.", "Negative ink-label crops are allowed and counted; real image and supervision crops must be nonzero.", "No model training, validation quality gain, external peer review, or causal Aletheion benefit is inferred."],
    }
    destination = args.output_dir / "real-load-report.json"
    write_json(destination, result)
    log("load_complete", shared_crop_hashes_equal=len(common), output=str(destination))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("discover", "sample", "plan-load", "load"))
    parser.add_argument("--config", type=Path, default=CONFIGS / "aligned21_hybrid_3d2d.json")
    parser.add_argument("--source-manifest", type=Path, default=CONFIGS / "aligned21_source_identity.json")
    parser.add_argument("--data-root", type=Path, default=ROOT / "runtime/data/ink_9um")
    parser.add_argument("--ct-manifest", type=Path, default=ROOT / "runtime/ct-manifest.json")
    parser.add_argument("--label-summary", type=Path, default=ROOT / "runtime/labels-summary.json")
    parser.add_argument("--label-report", type=Path, default=ROOT / "runtime/data-access-report.json")
    parser.add_argument("--discovery", type=Path, default=ROOT / "runtime/real-discovery.json")
    parser.add_argument("--load-plan", type=Path, default=ROOT / "runtime/real-load-plan.json")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "runtime/real-results")
    parser.add_argument("--patches-per-representation", type=int, default=4, help="first N actual training patches per representation; 0 uses every genuine discovered patch")
    parser.add_argument("--batches", type=int, default=90)
    parser.add_argument("--load-batches", type=int, default=1)
    args = parser.parse_args()
    if args.patches_per_representation < 0 or args.batches <= 0:
        parser.error("patch limit must be nonnegative and batch count positive")
    if args.stage == "plan-load":
        plan_load(args)
        return
    api = production()
    {"discover": discover, "sample": sample, "load": load}[args.stage](args, api)


if __name__ == "__main__":
    main()
