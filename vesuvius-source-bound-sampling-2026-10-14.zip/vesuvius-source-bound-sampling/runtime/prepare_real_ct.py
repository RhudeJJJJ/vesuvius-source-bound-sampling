"""Bounded, source-hashed CT stores for actual InkDataset reads.

Only explicitly requested chunks are populated. These stores are not full
prepared volumes; callers must preflight every CT read against completed tiles.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import itertools
import json
from pathlib import Path
import threading
import urllib.request
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / 'vendor/villa/vesuvius/src/vesuvius/ink_detection/configs/aligned21_source_identity.json'
DATA = ROOT / 'runtime/data/ink_9um/labels'
CACHE = ROOT / 'runtime/ct-source-cache'
RECORDS = ROOT / 'runtime/ct-manifest.json'
LOCK = threading.Lock()
OBJECT_LOCKS = {}

def object_lock(key):
    with LOCK:
        return OBJECT_LOCKS.setdefault(str(key), threading.Lock())

def write_bytes_atomic(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    part = path.with_name(path.name + f'.{threading.get_ident()}.partial')
    part.write_bytes(raw)
    part.replace(path)

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    part = path.with_suffix(path.suffix + '.partial')
    part.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    part.replace(path)

def fetch(url, records):
    with object_lock(url):
        return _fetch_locked(url, records)

def _fetch_locked(url, records):
    key = hashlib.sha256(url.encode()).hexdigest()
    path = CACHE / 'bytes' / key
    old = records.get(url)
    if path.exists() and old:
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != old['sha256']:
            raise ValueError('Cache hash mismatch: ' + url)
        return raw
    with urllib.request.urlopen(url, timeout=90) as response:
        raw = response.read(20_000_001)
        if len(raw) > 20_000_000:
            raise ValueError('Per-object download cap exceeded: ' + url)
        observed = {'url': url, 'resolved_url': response.url,
                    'status': response.status, 'bytes': len(raw),
                    'downloaded_at_utc': datetime.now(timezone.utc).isoformat(),
                    'sha256': hashlib.sha256(raw).hexdigest()}
    write_bytes_atomic(path, raw)
    with LOCK:
        records[url] = observed
    return raw

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['metadata', 'prepare'])
    parser.add_argument('--load-plan', type=Path)
    parser.add_argument('--workers', type=int, default=6)
    args = parser.parse_args()
    import numpy as np
    import zarr
    from numcodecs import Blosc
    from vesuvius.ink_detection.preprocessing.prepare_9um_isotropic_input import centered_slice
    rows = json.loads(REFERENCE.read_text(encoding='utf-8'))['representations']
    release_report = json.loads((ROOT / 'runtime/data-access-report.json').read_text())
    released_metadata = {item['release_entry']['path']: item['receipt']
                         for item in release_report['metadata_objects']}
    def original_label_metadata(relative):
        receipt = released_metadata[relative]
        path = Path(receipt['path'])
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != receipt['sha256']:
            raise ValueError('Original label metadata bytes changed: ' + relative)
        return json.loads(raw)
    state = json.loads(RECORDS.read_text()) if RECORDS.exists() else {
        'scope': 'Only completed output tiles are valid CT reads; unpopulated tiles are unknown, not established zero.',
        'source_objects': {}, 'representations': {}}
    records = state['source_objects']

    def metadata(row):
        rep = row['representation_key']
        aligned = rep.startswith('public_')
        family = 'aligned-scrollprizeorg-21slices' if aligned else 'native9-scrollprizeorg-21slices'
        url = 'https://vesuvius-challenge-open-data.s3.amazonaws.com/' + row['source_link'].split('#', 1)[1]
        level = '2' if aligned else '0'
        schema = json.loads(fetch(url + level + '/.zarray', records))
        attrs = json.loads(fetch(url + '.zattrs', records))
        source_shape = schema['shape']
        if schema['dtype'] != '|u1' or len(source_shape) != 3:
            raise ValueError(f'Unsupported actual source schema {rep}: {schema}')
        shape = [21, *source_shape[1:]] if aligned else source_shape
        dest = DATA / family / row['segment'] / 'surface-volume.zarr'
        previous = state['representations'].get(rep, {})
        if previous and (previous['original_source_volume_url'] != url or previous['source_schema'] != schema):
            raise ValueError('Refusing changed source/schema with an existing prepared store: ' + rep)
        label_meta = next(dest.parent.glob('*_supervision_mask*.zarr/0/.zarray'), None)
        prefix = f'ink_9um/labels/{family}/{row["segment"]}/{row["segment"]}_supervision_mask.zarr/'
        label_schema = original_label_metadata(prefix + '0/.zarray')
        label_shape = label_schema['shape']
        if label_meta is not None and json.loads(label_meta.read_text()) != label_schema:
            raise ValueError('Materialized label schema differs from observed original: ' + rep)
        if shape != label_shape:
            raise ValueError(f'Source/label shape mismatch {rep}: {shape} vs {label_shape}')
        label_attrs = original_label_metadata(prefix + '.zattrs')
        if aligned:
            recorded_shape = label_attrs.get('source_shape_zyx')
            if recorded_shape is not None and recorded_shape != source_shape:
                raise ValueError('Aligned published source shape mismatch: ' + rep)
            recorded_level = label_attrs.get('source_surface_volume_level')
            if recorded_level is not None and str(recorded_level) != level:
                raise ValueError('Aligned published source level mismatch: ' + rep)
            original = label_attrs.get('source_surface_volume')
            if original is not None and original.rstrip('/') != url.rstrip('/'):
                raise ValueError('Aligned label/source scanframe mismatch: ' + rep)
            recorded_slice = label_attrs.get('source_z_slice')
            if recorded_slice is not None and list(centered_slice(source_shape[0], 84)) != recorded_slice:
                raise ValueError('Aligned published source Z slice mismatch: ' + rep)
        group = zarr.open_group(str(dest), mode='a', **({'zarr_format': 2} if int(zarr.__version__.split('.')[0]) >= 3 else {}))
        if '0' not in group:
            create = group.create_array if int(zarr.__version__.split('.')[0]) >= 3 else group.create_dataset
            create('0', shape=shape, chunks=(shape[0], 128, 128),
                   dtype='u1', fill_value=0,
                   compressor=Blosc(cname='zstd', clevel=5, shuffle=Blosc.BITSHUFFLE))
        elif (list(group['0'].shape) != shape or group['0'].dtype != np.dtype('u1')
              or tuple(group['0'].chunks) != (shape[0], 128, 128)):
            raise ValueError('Existing output schema mismatch: ' + rep)
        group.attrs.update({'source': url, 'source_level': level,
                            'bounded_validation_store': True,
                            'unpopulated_tiles': 'UNKNOWN; not valid for reading',
                            'source_shape_zyx': source_shape})
        with LOCK:
            state['representations'][rep] = {
                'original_source_volume_url': url, 'source_level': level,
                'source_schema': schema, 'source_attributes': attrs,
                'output_shape': shape, 'output_store': str(dest),
                'completed_tiles': previous.get('completed_tiles', {})}
        print('metadata ' + rep + ' ' + str(shape), flush=True)

    if args.stage == 'metadata':
        try:
            with ThreadPoolExecutor(max_workers=args.workers) as pool:
                list(pool.map(metadata, rows))
        finally:
            dump(RECORDS, state)
        return
    if args.load_plan is None:
        parser.error('--load-plan is required for prepare')
    plan = json.loads(args.load_plan.read_text())
    requested = plan.get('patches', plan.get('load_patches', [])) if isinstance(plan, dict) else plan
    tiles = set()
    for patch in requested:
        rep = patch['representation_key']
        entry = state['representations'][rep]
        _, y0, x0, _, y1, x1 = patch['bbox']
        for cy in range(max(0, y0) // 128, (min(y1, entry['output_shape'][1]) + 127) // 128):
            for cx in range(max(0, x0) // 128, (min(x1, entry['output_shape'][2]) + 127) // 128):
                tiles.add((rep, cy, cx))
    def prepare(tile):
        rep, cy, cx = tile
        entry = state['representations'][rep]
        tile_key = f'{cy}.{cx}'
        if tile_key in entry['completed_tiles']:
            record = entry['completed_tiles'][tile_key]
            _, ya, xa, zdepth, yb, xb = record['bbox']
            output = zarr.open_group(entry['output_store'], mode='r')['0'][:, ya:yb, xa:xb]
            if (output.shape[0] != zdepth or hashlib.sha256(np.asarray(output).tobytes()).hexdigest() != record['decoded_sha256']):
                raise ValueError('Previously completed output tile no longer matches: ' + rep + '/' + tile_key)
            return
        aligned = rep.startswith('public_')
        schema = entry['source_schema']
        shape, chunks = schema['shape'], schema['chunks']
        z0, z1 = centered_slice(shape[0], 84) if aligned else (0, shape[0])
        y0, y1 = cy * 128, min((cy + 1) * 128, shape[1])
        x0, x1 = cx * 128, min((cx + 1) * 128, shape[2])
        source_dir = CACHE / 'stores' / hashlib.sha256(rep.encode()).hexdigest()[:16] / entry['source_level']
        source_dir.mkdir(parents=True, exist_ok=True)
        schema_path = source_dir / '.zarray'
        with LOCK:
            if not schema_path.exists():
                dump(schema_path, schema)
            elif json.loads(schema_path.read_text()) != schema:
                raise ValueError('Cached source schema changed: ' + rep)
        coords = itertools.product(range(z0 // chunks[0], (z1 + chunks[0] - 1) // chunks[0]),
                                   range(y0 // chunks[1], (y1 + chunks[1] - 1) // chunks[1]),
                                   range(x0 // chunks[2], (x1 + chunks[2] - 1) // chunks[2]))
        used = []
        for coord in coords:
            key = schema.get('dimension_separator', '.').join(map(str, coord))
            url = entry['original_source_volume_url'] + entry['source_level'] + '/' + key
            raw = fetch(url, records)  # Any missing or failed CT object aborts.
            target = source_dir / key
            with object_lock(target):
                if target.exists():
                    if hashlib.sha256(target.read_bytes()).digest() != hashlib.sha256(raw).digest():
                        raise ValueError('Cached source chunk changed: ' + str(target))
                else:
                    write_bytes_atomic(target, raw)
            used.append(url)
        source = zarr.open_array(str(source_dir), mode='r')
        block = np.asarray(source[z0:z1, y0:y1, x0:x1])
        if aligned:
            pooled = np.rint(block.astype(np.float32).reshape(21, 4, y1-y0, x1-x0).mean(axis=1)).astype(np.uint8)
            # Independent arithmetic check of the documented half-even four-plane mean.
            sums = block.astype(np.uint16).reshape(21, 4, y1-y0, x1-x0).sum(axis=1)
            independent = np.rint(sums.astype(np.float64) / 4).astype(np.uint8)
            if not np.array_equal(pooled, independent):
                raise ValueError('Pooling arithmetic mismatch: ' + rep)
        else:
            pooled = block
        group = zarr.open_group(entry['output_store'], mode='a')
        group['0'][:, y0:y1, x0:x1] = pooled
        if not np.array_equal(group['0'][:, y0:y1, x0:x1], pooled):
            raise ValueError('Output roundtrip mismatch: ' + rep)
        with LOCK:
            entry['completed_tiles'][tile_key] = {
                'bbox': [0, y0, x0, len(pooled), y1, x1],
                'source_bbox': [z0, y0, x0, z1, y1, x1],
                'source_chunk_urls': used,
                'decoded_sha256': hashlib.sha256(pooled.tobytes()).hexdigest(),
                'nonzero_voxels': int(np.count_nonzero(pooled))}
        print('prepared ' + rep + ' tile=' + tile_key, flush=True)
    try:
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            list(pool.map(prepare, sorted(tiles)))
    finally:
        dump(RECORDS, state)

if __name__ == '__main__':
    main()
