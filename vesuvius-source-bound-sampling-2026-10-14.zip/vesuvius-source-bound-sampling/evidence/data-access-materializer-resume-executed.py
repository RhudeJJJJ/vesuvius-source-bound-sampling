#!/usr/bin/env python3
"""Bounded, resumable access to the public ink_9um release.

Only released objects are written; an absent local chunk is never claimed zero.
The complete API listing plus object hashes is retained to support that distinction.
No authentication is used. Buckets are mutable, so URL alone is not a pin.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import pathlib
import re
import threading
import time
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timezone

API = "https://huggingface.co/api/buckets/scrollprize/datasets/tree/"
RAW = "https://huggingface.co/buckets/scrollprize/datasets/resolve/"
DATASET = "ink_9um"


class PublicFetcher:
    def __init__(self, root: pathlib.Path, cap: int):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.cap = cap
        self.total = 0
        self.records = []
        self.lock = threading.Lock()

    def fetch(self, url: str, relative: str, maximum=2_500_000):
        path = (self.root / relative).resolve()
        if not path.is_relative_to(self.root):
            raise ValueError("unsafe destination")
        receipt = path.with_name(path.name + ".receipt.json")
        if path.exists() and receipt.exists():
            data = path.read_bytes()
            old = json.loads(receipt.read_text("utf-8"))
            if old["url"] == url and hashlib.sha256(data).hexdigest() == old["sha256"]:
                with self.lock:
                    self.records.append(dict(old, cache_verified=True))
                return data, old
        with self.lock:
            available = self.cap - self.total
        if available < 1:
            raise RuntimeError("download cap reached")
        limit = min(maximum, available)
        request = urllib.request.Request(url, headers={"User-Agent": "ink-source-identity-reproduction/1.0"})
        response = None
        for attempt in range(4):
            try:
                response = urllib.request.urlopen(request, timeout=60)
                break
            except (urllib.error.URLError, TimeoutError) as error:
                if isinstance(error, urllib.error.HTTPError) and error.code not in {429, 500, 502, 503, 504}:
                    raise
                if attempt == 3:
                    raise
                time.sleep(2 ** attempt)
        with response:
            length = response.headers.get("Content-Length")
            if length and int(length) > limit:
                raise RuntimeError(f"object larger than bounded fetch: {length} > {limit}: {url}")
            data = response.read(limit + 1)
            if len(data) > limit:
                raise RuntimeError(f"response exceeds cap: {url}")
            record = {
                "url": url, "resolved_url": response.url,
                "status": response.status, "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "etag": response.headers.get("ETag"),
                "link": response.headers.get("Link"),
                "observed_at": datetime.now(timezone.utc).isoformat(),
                "path": str(path),
            }
        with self.lock:
            if self.total + len(data) > self.cap:
                raise RuntimeError("aggregate cap reached")
            self.total += len(data)
            self.records.append(record)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".partial")
        temporary.write_bytes(data)
        temporary.replace(path)
        receipt.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
        return data, record

    def tree(self, prefix, recursive=True):
        url = API + urllib.parse.quote(prefix, safe="/") + "?recursive=" + str(recursive).lower()
        result = []
        pages = []
        page = 0
        while url:
            relative = "api/" + prefix + f".recursive{recursive}.page{page}.json"
            data, record = self.fetch(url, relative)
            items = json.loads(data)
            if not isinstance(items, list):
                raise ValueError("API response is not an entry array")
            result.extend(items)
            pages.append(record)
            matches = re.findall(r'<([^>]+)>;\s*rel="next"', record.get("link") or "")
            url = matches[0] if matches else None
            if url and not url.startswith(API):
                raise ValueError("unexpected pagination authority")
            page += 1
        return result, pages


def released_url(path):
    return RAW + urllib.parse.quote(path, safe="/") + "?download=true"


def probe(args):
    fetcher = PublicFetcher(pathlib.Path(args.cache), args.cap)
    source_rows = json.loads(pathlib.Path(args.source_rows).read_text("utf-8"))["all_source_rows"]
    representations = []
    for row in source_rows:
        name = row[0]["text"]
        family = "native9-scrollprizeorg-21slices" if not name.startswith("pherc") else "aligned-scrollprizeorg-21slices"
        representations.append((family, name))
    labels = []
    pages = []
    def list_representation(identity):
        family, name = identity
        prefix = f"ink_9um/labels/{family}/{name}"
        return fetcher.tree(prefix, recursive=False)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for entries, receipts in pool.map(list_representation, representations):
            labels.extend(entries)
            pages.extend(receipts)
    stores = [x for x in labels if x["type"] == "directory" and x["path"].endswith(".zarr")]
    def list_store(item):
        return fetcher.tree(item["path"], recursive=False)
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        for entries, receipts in pool.map(list_store, stores):
            labels.extend(entries)
            pages.extend(receipts)
    selected = stores if args.all_representations else [x for x in stores if x["path"].split("/")[3] in {"pherc0139-w028", "w044"}]
    def list_level0(store):
        entries, receipts = fetcher.tree(store["path"] + "/0", recursive=True)
        print(json.dumps({"listed_store": store["path"], "entries": len(entries), "bytes": sum(x.get("size", 0) for x in entries)}), flush=True)
        return entries, receipts
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for entries, receipts in pool.map(list_level0, selected):
            labels.extend(entries)
            pages.extend(receipts)
    # Every store's level-0 .zarray is fetched directly. Other metadata files
    # come from the actual nonrecursive directory listing, not guessed keys.
    by_path = {x["path"]: x for x in labels}
    labels = list(by_path.values())
    files = [x for x in labels if x["type"] == "file"]
    by_representation = {}
    for item in files:
        bits = item["path"].split("/")
        if len(bits) < 5:
            raise ValueError("unexpected label path")
        key = "/".join(bits[2:4])
        summary = by_representation.setdefault(key, {"files": 0, "bytes": 0, "stores": set()})
        summary["files"] += 1
        summary["bytes"] += item.get("size", 0)
        summary["stores"].add(bits[4])
    metadata = [x for x in files if x["path"].endswith(("/.zarray", "/.zattrs", "/.zgroup", "/zarr.json", "/.zmetadata"))]
    def fetch_metadata(item):
        data, record = fetcher.fetch(released_url(item["path"]), "objects/" + item["path"], maximum=max(item["size"], 1) + 4096)
        return {"release_entry": item, "receipt": record, "metadata": json.loads(data)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        meta_objects = list(pool.map(fetch_metadata, metadata))
    existing_arrays = {x["release_entry"]["path"] for x in meta_objects}
    def fetch_level0(item):
        path = item["path"] + "/0/.zarray"
        raw, rec = fetcher.fetch(released_url(path), "objects/" + path)
        return {"release_entry": {"path": path, "size": len(raw)}, "receipt": rec, "metadata": json.loads(raw)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        meta_objects.extend(pool.map(fetch_level0, [x for x in stores if x["path"] + "/0/.zarray" not in existing_arrays]))
    source_metadata = []
    for row in source_rows:
        name = row[0]["text"]
        if name not in {"pherc0139-w028", "w044"}:
            continue
        parsed = urllib.parse.urlsplit(row[2]["links"][0])
        prefix = "https://vesuvius-challenge-open-data.s3.amazonaws.com/" + parsed.fragment
        for suffix in (".zattrs", "0/.zarray", "2/.zarray"):
            url = prefix + suffix
            try:
                raw, rec = fetcher.fetch(url, "source-ct/" + name + "/" + suffix)
                source_metadata.append({"annotation": name, "suffix": suffix, "receipt": rec, "metadata": json.loads(raw)})
            except urllib.error.HTTPError as error:
                source_metadata.append({"annotation": name, "suffix": suffix, "status": error.code, "url": url})
    report = {
        "kind": "public-release-data-access", "listing_complete": args.all_representations,
        "complete_level0_store_prefixes": [x["path"] for x in selected],
        "all29_metadata_fetched": len(representations) == 29,
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "api": API, "raw": RAW,
        "listing_pages": pages, "file_count": len(files),
        "total_listed_file_bytes": sum(x.get("size", 0) for x in files),
        "representations": {k: dict(v, stores=sorted(v["stores"])) for k, v in sorted(by_representation.items())},
        "metadata_objects": meta_objects, "source_ct_metadata": source_metadata,
        "downloaded_bytes_this_run": fetcher.total,
        "chunk_manifest": args.manifest,
        "boundaries": ["No label or CT chunk values have yet been decoded.", "Complete listing does not imply complete object download.", "Absent local files cannot be interpreted as genuine zero chunks."],
    }
    destination = pathlib.Path(args.report)
    destination.parent.mkdir(parents=True, exist_ok=True)
    manifest = pathlib.Path(args.manifest)
    manifest.parent.mkdir(parents=True, exist_ok=True)
    with manifest.open("w", encoding="utf-8") as stream:
        for item in sorted(files, key=lambda x: x["path"]):
            stream.write(json.dumps(item, separators=(",", ":")) + "\n")
    report["chunk_manifest_sha256"] = hashlib.sha256(manifest.read_bytes()).hexdigest()
    blobs = {x["xetHash"]: x["size"] for x in files}
    report["unique_blob_count"] = len(blobs)
    report["unique_blob_bytes"] = sum(blobs.values())
    destination.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("file_count", "total_listed_file_bytes", "downloaded_bytes_this_run", "representations")}, indent=2), flush=True)


def download(args):
    report = json.loads(pathlib.Path(args.report).read_text("utf-8"))
    selected = []
    if "chunk_manifest" in report:
        manifest = pathlib.Path(report["chunk_manifest"])
        if hashlib.sha256(manifest.read_bytes()).hexdigest() != report["chunk_manifest_sha256"]:
            raise ValueError("manifest hash mismatch")
        listed = (json.loads(line) for line in manifest.read_text("utf-8").splitlines())
    else:
        listed = report["chunk_files"]
    for item in listed:
        if not args.prefix or any(item["path"].startswith(p) for p in args.prefix):
            selected.append(item)
    expected = sum(x["size"] for x in selected)
    print(json.dumps({"selected_files": len(selected), "release_bytes": expected, "cap": args.cap}), flush=True)
    if expected > args.cap:
        raise RuntimeError("selected release objects exceed explicit aggregate cap")
    fetcher = PublicFetcher(pathlib.Path(args.cache), args.cap)
    def get(item):
        _, record = fetcher.fetch(released_url(item["path"]), item["path"], max(item["size"], 1) + 4096)
        if record["bytes"] != item["size"]:
            raise RuntimeError("object size differs from listing; release may have changed")
        return dict(record, release_xet_hash=item.get("xetHash"))
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        records = list(pool.map(get, selected))
    pathlib.Path(args.receipts).write_text(json.dumps({"objects": records, "all_selected_objects_complete": True, "downloaded_bytes_this_run": fetcher.total}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"completed_objects": len(records), "downloaded_bytes": fetcher.total}), flush=True)


def materialize(args, download_only=False):
    """Deduplicate released blobs, decode every chunk, omit only proven fill chunks."""
    if not download_only:
        import numpy as np
        from numcodecs import get_codec
    report = json.loads(pathlib.Path(args.report).read_text("utf-8"))
    if "chunk_manifest" in report:
        manifest = pathlib.Path(report["chunk_manifest"])
        if hashlib.sha256(manifest.read_bytes()).hexdigest() != report["chunk_manifest_sha256"]:
            raise ValueError("manifest hash mismatch")
        files = [json.loads(line) for line in manifest.read_text("utf-8").splitlines()]
    else:
        files = report["chunk_files"]
    files = [x for x in files if not args.prefix or any(x["path"].startswith(p) for p in args.prefix)]
    # Root metadata and level 0 only. In particular, the native pyramids above
    # level 0 are never needed by this discovery verification.
    files = [x for x in files if len(x["path"].split("/")) == 6 or (len(x["path"].split("/")) == 7 and x["path"].split("/")[5] == "0")]
    groups = {}
    for item in files:
        groups.setdefault(item["xetHash"], []).append(item)
    unique_bytes = sum(group[0]["size"] for group in groups.values())
    print(json.dumps({"selected_files": len(files), "unique_blobs": len(groups), "unique_download_bytes": unique_bytes}), flush=True)
    if unique_bytes > args.cap:
        raise RuntimeError("deduplicated objects exceed explicit cap")
    fetcher = PublicFetcher(pathlib.Path(args.cache), args.cap)
    if args.xet:
        # Official batch transport skips the per-object HTTP resolve request.
        # token=False explicitly keeps this public release access anonymous.
        from huggingface_hub import HfApi
        from huggingface_hub._buckets import BucketFile
        api = HfApi(token=False)
        pending = []
        for xet_hash, group in groups.items():
            sample = group[0]
            blob = fetcher.root / "blobs" / xet_hash
            receipt_path = blob.with_name(blob.name + ".receipt.json")
            if blob.exists() and receipt_path.exists():
                receipt = json.loads(receipt_path.read_text("utf-8"))
                raw = blob.read_bytes()
                if receipt.get("sha256") == hashlib.sha256(raw).hexdigest() and receipt.get("url") == released_url(sample["path"]) and len(raw) == sample["size"]:
                    continue
            blob.parent.mkdir(parents=True, exist_ok=True)
            pending.append((xet_hash, sample, blob))
        for start in range(0, len(pending), 512):
            batch = pending[start:start + 512]
            # Pending names are not treated as authenticated cached objects.
            tasks = [(BucketFile(**sample), str(blob) + ".xetpending") for _, sample, blob in batch]
            api.download_bucket_files("scrollprize/datasets", tasks, token=False, raise_on_missing_files=True)
            for xet_hash, sample, blob in batch:
                temporary = pathlib.Path(str(blob) + ".xetpending")
                raw = temporary.read_bytes()
                if len(raw) != sample["size"]:
                    raise ValueError("Xet returned length differing from complete public manifest")
                receipt = {"url": released_url(sample["path"]), "transport": "huggingface_hub.download_bucket_files with token=False", "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "release_xet_hash": xet_hash, "observed_at": datetime.now(timezone.utc).isoformat(), "path": str(blob)}
                temporary.replace(blob)
                blob.with_name(blob.name + ".receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
                fetcher.total += len(raw)
            print(json.dumps({"xet_completed": min(start + len(batch), len(pending)), "xet_total": len(pending), "downloaded_payload_bytes": fetcher.total}), flush=True)
    output = pathlib.Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    # Release paths are immutable within this invocation and each path occurs
    # exactly once in the manifest. Capture the preexisting output inventory
    # once: omitted fill chunks then require no slow Windows path resolution.
    # A fill group's paths cannot collide with paths of a nonfill group.
    existing_output_files = {p.relative_to(output).as_posix() for p in output.rglob("*") if p.is_file()}
    for item in files:
        release_path = pathlib.PurePosixPath(item["path"])
        if release_path.is_absolute() or ".." in release_path.parts or "\\" in item["path"] or ":" in item["path"]:
            raise ValueError("unsafe release object path")
    array_metadata = {x["release_entry"]["path"].removesuffix("/0/.zarray"): x["metadata"] for x in report["metadata_objects"] if x["release_entry"]["path"].endswith("/0/.zarray")}
    count = 0
    counter_lock = threading.Lock()
    def obtain(pair):
        nonlocal count
        xet_hash, group = pair
        sample = group[0]
        data, receipt = fetcher.fetch(released_url(sample["path"]), "blobs/" + xet_hash, max(sample["size"], 1) + 4096)
        if len(data) != sample["size"] or any(x["size"] != len(data) for x in group):
            raise ValueError("public listing size differs within identical xet hash")
        observed_etag = (receipt.get("etag") or "").strip('"')
        if receipt.get("release_xet_hash") != xet_hash and observed_etag != xet_hash:
            raise ValueError("download lacks matching publisher Xet identity; mutable file cannot be accepted solely by size")
        proof = {"xet_hash": xet_hash, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data), "receipt": receipt, "paths": [x["path"] for x in group]}
        chunk_paths = [x for x in group if not x["path"].rsplit("/", 1)[1].startswith(".")]
        proof["all_fill"] = False
        if chunk_paths and not download_only:
            specs = [array_metadata[x["path"].rsplit("/0/", 1)[0]] for x in chunk_paths]
            signature = [(s["dtype"], s["chunks"], s["compressor"], s["fill_value"], s["order"]) for s in specs]
            if any(s != signature[0] for s in signature):
                raise ValueError("same compressed hash has differing decode contracts")
            spec = specs[0]
            raw = get_codec(spec["compressor"]).decode(data) if spec["compressor"] else data
            decoded = np.frombuffer(raw, dtype=np.dtype(spec["dtype"])).reshape(spec["chunks"], order=spec["order"])
            fill = spec["fill_value"]
            proof["decoded_sha256"] = hashlib.sha256(raw).hexdigest()
            proof["decoded_bytes"] = len(raw)
            proof["all_fill"] = bool(np.all(decoded == fill))
            proof["nonzero_count"] = int(np.count_nonzero(decoded))
            proof["values"] = np.unique(decoded).tolist()
            if not proof["all_fill"]:
                nz = np.argwhere(decoded != fill)
                proof["first_nonfill_in_chunk_zyx"] = nz[0].tolist()
        for item in ([] if download_only else group):
            if proof["all_fill"] and item["path"] not in existing_output_files:
                continue
            destination = (output / item["path"]).resolve()
            if not destination.is_relative_to(output):
                raise ValueError("unsafe release path")
            # Proven fill chunks need no physical local object under Zarr2.
            # All other released objects remain byte identical.
            if proof["all_fill"]:
                if destination.exists():
                    if hashlib.sha256(destination.read_bytes()).hexdigest() != proof["sha256"]:
                        raise ValueError("unexpected existing chunk")
                    destination.unlink()
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                if not destination.exists() or hashlib.sha256(destination.read_bytes()).hexdigest() != proof["sha256"]:
                    destination.write_bytes(data)
        with counter_lock:
            count += 1
            if count % 100 == 0:
                print(json.dumps({"completed_blobs": count, "total_blobs": len(groups), "downloaded_bytes": fetcher.total}), flush=True)
        return proof
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        proofs = list(pool.map(obtain, groups.items()))
    receipts = pathlib.Path(args.receipts)
    receipts.parent.mkdir(parents=True, exist_ok=True)
    with receipts.open("w", encoding="utf-8") as stream:
        for proof in proofs:
            stream.write(json.dumps(proof, separators=(",", ":")) + "\n")
    summary = {"complete": True, "local_stores_complete": not download_only, "selected_files": len(files), "unique_blobs": len(groups), "unique_blob_bytes": unique_bytes, "downloaded_bytes": fetcher.total,
        "omitted_proven_fill_file_count": sum(len(p["paths"]) for p in proofs if p["all_fill"]), "receipts": str(receipts), "receipts_sha256": hashlib.sha256(receipts.read_bytes()).hexdigest(),
        "output_root": None if download_only else str(output), "input_manifest_sha256": report.get("chunk_manifest_sha256"), "preexisting_output_inventory_sha256": hashlib.sha256("\n".join(sorted(existing_output_files)).encode()).hexdigest(), "all_unknown_local_absences": "not yet materialized" if download_only else "none among complete selected level0 stores"}
    pathlib.Path(args.summary).write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["probe", "download", "prefetch", "materialize"])
    parser.add_argument("--cache", default="evidence/data-access-cache")
    parser.add_argument("--report", default="runtime/data-access-report.json")
    parser.add_argument("--source-rows", default="evidence/vesuvius-physical-source-rows.json")
    parser.add_argument("--cap", type=int, default=20_000_000)
    parser.add_argument("--prefix", action="append")
    parser.add_argument("--all-representations", action="store_true", help="List all released chunks rather than only both target representations; requires a larger cap")
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--receipts", default="evidence/data-access-downloads.json")
    parser.add_argument("--manifest", default="evidence/data-access-label-manifest.jsonl")
    parser.add_argument("--output", default="runtime/data")
    parser.add_argument("--summary", default="evidence/data-access-materialization-summary.json")
    parser.add_argument("--xet", action="store_true", help="Use official anonymous Hugging Face Xet batch transport (requires huggingface_hub and hf_xet); cap bounds returned object payload, not transport overhead")
    args = parser.parse_args()
    if args.mode == "probe":
        probe(args)
    elif args.mode == "download":
        download(args)
    else:
        materialize(args, download_only=args.mode == "prefetch")


if __name__ == "__main__":
    main()
